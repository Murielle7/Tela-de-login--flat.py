Rails.application.routes.draw do
  devise_for :users, controllers: { sessions: 'sessions' }

  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get 'up' => 'rails/health#show', as: :rails_health_check

  # Defines the root path route ("/")
  root 'debitos#index'

  devise_scope :user do
    get '/login', to: 'sessions#new', as: :login
    get '/entrar', to: 'sessions#new'
    post '/login', to: 'sessions#create'
    get '/logout', to: 'sessions#destroy', as: :logout
    get '/sair', to: 'sessions#destroy'
    delete '/logout', to: 'sessions#destroy'
  end

  resources :debitos, only: %i[index show create] do
    resources :parcelas, only: [:show] do
      resources :guias, only: %i[show create update]
    end
  end

  namespace :admin do
    root 'home#index'
    resources :categorias_debito
    resources :indicadores_financeiros
    resources :itens_arrecadacao do
      get :autocomplete, on: :collection
    end
    resources :users
    resources :guias, only: %i[index show] do
      post :registrar_saj, on: :member
      get :atualizar_saj, on: :collection
    end
    resources :debitos do
      resources :parcelas do
        put :atualizar, on: :member
        post :confirmar, on: :collection
        post :negar, on: :collection
      end
    end
  end
end
