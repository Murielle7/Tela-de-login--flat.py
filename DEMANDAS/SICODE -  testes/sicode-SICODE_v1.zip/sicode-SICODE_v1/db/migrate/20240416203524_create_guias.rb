class CreateGuias < ActiveRecord::Migration[7.1]
  def change
    create_table :guias do |t|
      t.references :parcela, null: false, foreign_key: true
      t.string :numero
      t.date :data_emissao, default: Date.today
      t.date :data_vencimento
      t.date :data_pagamento
      t.decimal :valor, precision: 15, scale: 2, default: "0.0", null: false
      t.decimal :valor_pago, precision: 15, scale: 2, default: "0.0", null: false
      t.integer :situacao, default: 0, null: false
      t.integer :tipo, default: 0, null: false
      t.boolean :lancado_spg, default: false
      t.boolean :ativa, default: true
      t.text :obs
      t.string :cpf
      t.string :cnpj
      t.string :identificacao_sacado

      t.timestamps
    end
  end
end
