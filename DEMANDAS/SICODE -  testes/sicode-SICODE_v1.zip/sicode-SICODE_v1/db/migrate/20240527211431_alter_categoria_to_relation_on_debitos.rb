class AlterCategoriaToRelationOnDebitos < ActiveRecord::Migration[7.1]
  def change
    remove_column :debitos, :categoria, :string
    add_column :debitos, :categoria_debito_id, :bigint
  end
end
