class RemoveIndexEmailNulo < ActiveRecord::Migration[7.1]
  def up
    remove_index :users, name: 'index_users_on_email'
    add_index :users, :email, unique: true, where: "email IS NOT NULL AND TRIM(email) != ''"
  end

  def down
    raise ActiveRecord::IrreversibleMigration
  end
end
