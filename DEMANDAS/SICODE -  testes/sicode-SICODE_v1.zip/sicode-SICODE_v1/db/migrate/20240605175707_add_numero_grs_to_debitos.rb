class AddNumeroGrsToDebitos < ActiveRecord::Migration[7.1]
  def change
    add_column :debitos, :numero_grs, :string
  end
end
