class RemoveCorrecaoOptionsFromDebitoItens < ActiveRecord::Migration[7.1]
  def change
    remove_column :debito_itens, :aplicar_correcao, :boolean, default: false
    remove_column :debito_itens, :aplicar_juros, :boolean, default: false
    remove_column :debito_itens, :aplicar_multa, :boolean, default: false
  end
end
