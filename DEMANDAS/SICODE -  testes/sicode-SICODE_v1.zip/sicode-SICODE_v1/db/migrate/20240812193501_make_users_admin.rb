class MakeUsersAdmin < ActiveRecord::Migration[7.1]
  def up
    User.where(username: %w[otvgaiao pmrbarbosa]).update(role: :admin)
  end

  def down; end
end
