class CreateItensArrecadacao < ActiveRecord::Migration[7.1]
  def change
    create_table :itens_arrecadacao do |t|
      t.string :nome
      t.boolean :ativo, default: true
      t.string :codigo_arrecadacao, index: true
      t.integer :tipo_taxa, index: true
      t.float :percent_emolumento
      t.text :detalhes
      t.date :data_inicio_vigencia
      t.date :data_fim_vigencia

      t.timestamps
    end
  end
end
