class AddCorrecaoOptionsToCategoriaDebitos < ActiveRecord::Migration[7.1]
  def change
    add_column :categoria_debitos, :aplicar_correcao, :boolean, default: false
    add_column :categoria_debitos, :aplicar_juros, :boolean, default: false
    add_column :categoria_debitos, :aplicar_multa, :boolean, default: false
  end
end
