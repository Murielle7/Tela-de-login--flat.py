class AddItemArrecadacaoIdToDebitosItens < ActiveRecord::Migration[7.1]
  def change
    add_column :debito_itens, :item_arrecadacao_id, :integer
  end
end
