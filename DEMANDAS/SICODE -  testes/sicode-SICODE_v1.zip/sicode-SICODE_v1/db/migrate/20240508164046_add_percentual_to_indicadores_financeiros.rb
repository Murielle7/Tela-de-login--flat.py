class AddPercentualToIndicadoresFinanceiros < ActiveRecord::Migration[7.1]
  def change
    add_column :indicadores_financeiros, :percentual, :boolean
  end
end
