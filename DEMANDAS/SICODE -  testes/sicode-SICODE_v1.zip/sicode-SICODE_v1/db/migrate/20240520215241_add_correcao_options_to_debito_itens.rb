class AddCorrecaoOptionsToDebitoItens < ActiveRecord::Migration[7.1]
  def change
    add_column :debito_itens, :aplicar_correcao, :boolean, default: false
    add_column :debito_itens, :aplicar_juros, :boolean, default: false
    add_column :debito_itens, :aplicar_multa, :boolean, default: false
  end
end
