class CreateParcelas < ActiveRecord::Migration[7.1]
  def change
    create_table :parcelas do |t|
      t.references :debito, null: false, foreign_key: true
      t.integer :numero, null: false, default: 1
      t.decimal :valor_ref, precision: 15, scale: 2, default: "0.0", null: false
      t.decimal :valor, precision: 15, scale: 2, default: "0.0", null: false
      t.decimal :correcao, precision: 15, scale: 2, default: "0.0", null: false
      t.decimal :juros, precision: 15, scale: 2, default: "0.0", null: false
      t.decimal :multa, precision: 15, scale: 2, default: "0.0", null: false
      t.date :data_ref
      t.date :data_vencimento
      t.date :data_atualizacao
      t.date :data_pagamento
      t.string :situacao, default: 'aguardando_pagamento'

      t.timestamps
    end
  end
end
