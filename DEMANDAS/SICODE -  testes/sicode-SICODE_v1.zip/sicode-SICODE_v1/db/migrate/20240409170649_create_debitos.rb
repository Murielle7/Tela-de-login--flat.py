class CreateDebitos < ActiveRecord::Migration[7.1]
  def change
    create_table :debitos do |t|
      t.string :nome
      t.string :cpf, index: true
      t.string :cnpj, index: true
      t.string :categoria
      t.string :situacao
      t.string :processo
      t.date :data_ref
      t.date :data_vencimento
      t.string :hash_acesso
      t.decimal :valor_ref, precision: 15, scale: 2, default: "0.0", null: false
      t.decimal :valor_atualizado, precision: 15, scale: 2, default: "0.0", null: false
      t.date :data_atualizacao
      t.text :descricao

      t.timestamps
    end
  end
end
