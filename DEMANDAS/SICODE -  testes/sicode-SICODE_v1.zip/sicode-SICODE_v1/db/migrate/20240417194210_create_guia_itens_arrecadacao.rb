class CreateGuiaItensArrecadacao < ActiveRecord::Migration[7.1]
  def change
    create_table :guia_itens_arrecadacao do |t|
      t.references :guia, null: false, foreign_key: true
      t.references :item_arrecadacao, null: false, foreign_key: true
      t.decimal :valor, precision: 15, scale: 2, default: "0.0", null: false
      t.string :obs

      t.timestamps
    end
  end
end
