# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[7.1].define(version: 2024_08_12_193501) do
  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "categoria_debitos", force: :cascade do |t|
    t.string "nome"
    t.boolean "ativo"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "aplicar_correcao", default: false
    t.boolean "aplicar_juros", default: false
    t.boolean "aplicar_multa", default: false
  end

  create_table "debito_itens", force: :cascade do |t|
    t.bigint "debito_id", null: false
    t.decimal "valor_ref", precision: 15, scale: 2, default: "0.0", null: false
    t.decimal "valor_atualizado", precision: 15, scale: 2, default: "0.0", null: false
    t.date "data_ref"
    t.date "data_atualizacao"
    t.decimal "correcao", precision: 15, scale: 2, default: "0.0", null: false
    t.decimal "juros", precision: 15, scale: 2, default: "0.0", null: false
    t.decimal "multa", precision: 15, scale: 2, default: "0.0", null: false
    t.text "descricao"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "item_arrecadacao_id"
    t.index ["debito_id"], name: "index_debito_itens_on_debito_id"
  end

  create_table "debitos", force: :cascade do |t|
    t.string "nome"
    t.string "cpf"
    t.string "cnpj"
    t.string "situacao"
    t.string "processo"
    t.date "data_ref"
    t.date "data_vencimento"
    t.string "hash_acesso"
    t.decimal "valor_ref", precision: 15, scale: 2, default: "0.0", null: false
    t.decimal "valor_atualizado", precision: 15, scale: 2, default: "0.0", null: false
    t.date "data_atualizacao"
    t.text "descricao"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.bigint "categoria_debito_id"
    t.string "numero_grs"
    t.string "numero_processo"
    t.index ["cnpj"], name: "index_debitos_on_cnpj"
    t.index ["cpf"], name: "index_debitos_on_cpf"
  end

  create_table "guia_itens_arrecadacao", force: :cascade do |t|
    t.bigint "guia_id", null: false
    t.bigint "item_arrecadacao_id", null: false
    t.decimal "valor", precision: 15, scale: 2, default: "0.0", null: false
    t.string "obs"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["guia_id"], name: "index_guia_itens_arrecadacao_on_guia_id"
    t.index ["item_arrecadacao_id"], name: "index_guia_itens_arrecadacao_on_item_arrecadacao_id"
  end

  create_table "guias", force: :cascade do |t|
    t.bigint "parcela_id", null: false
    t.string "numero"
    t.date "data_emissao", default: "2024-08-09"
    t.date "data_vencimento"
    t.date "data_pagamento"
    t.decimal "valor", precision: 15, scale: 2, default: "0.0", null: false
    t.decimal "valor_pago", precision: 15, scale: 2, default: "0.0", null: false
    t.integer "situacao", default: 0, null: false
    t.integer "tipo", default: 0, null: false
    t.boolean "lancado_spg", default: false
    t.boolean "ativa", default: true
    t.text "obs"
    t.string "cpf"
    t.string "cnpj"
    t.string "identificacao_sacado"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["parcela_id"], name: "index_guias_on_parcela_id"
  end

  create_table "indicadores_financeiros", force: :cascade do |t|
    t.string "nome"
    t.string "tipo"
    t.decimal "valor", precision: 10, scale: 2
    t.date "inicio"
    t.date "final"
    t.boolean "ativo", default: true
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "percentual"
    t.float "acumulado"
  end

  create_table "itens_arrecadacao", force: :cascade do |t|
    t.string "nome"
    t.boolean "ativo", default: true
    t.string "codigo_arrecadacao"
    t.integer "tipo_taxa"
    t.float "percent_emolumento"
    t.text "detalhes"
    t.date "data_inicio_vigencia"
    t.date "data_fim_vigencia"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "categoria_debito_id"
    t.index ["codigo_arrecadacao"], name: "index_itens_arrecadacao_on_codigo_arrecadacao"
    t.index ["tipo_taxa"], name: "index_itens_arrecadacao_on_tipo_taxa"
  end

  create_table "parcelas", force: :cascade do |t|
    t.bigint "debito_id", null: false
    t.integer "numero", default: 1, null: false
    t.decimal "valor_ref", precision: 15, scale: 2, default: "0.0", null: false
    t.decimal "valor", precision: 15, scale: 2, default: "0.0", null: false
    t.decimal "correcao", precision: 15, scale: 2, default: "0.0", null: false
    t.decimal "juros", precision: 15, scale: 2, default: "0.0", null: false
    t.decimal "multa", precision: 15, scale: 2, default: "0.0", null: false
    t.date "data_ref"
    t.date "data_vencimento"
    t.date "data_atualizacao"
    t.date "data_pagamento"
    t.string "situacao", default: "aguardando_pagamento"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "ativa", default: false
    t.index ["debito_id"], name: "index_parcelas_on_debito_id"
  end

  create_table "users", force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "username", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.integer "role", default: 0, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "nome"
    t.string "cpf"
    t.index ["email"], name: "index_users_on_email", unique: true
    t.index ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
    t.index ["username"], name: "index_users_on_username", unique: true
  end

  create_table "versions", force: :cascade do |t|
    t.string "item_type", null: false
    t.bigint "item_id", null: false
    t.string "event", null: false
    t.string "whodunnit"
    t.text "object"
    t.datetime "created_at"
    t.index ["item_type", "item_id"], name: "index_versions_on_item_type_and_item_id"
  end

  add_foreign_key "debito_itens", "debitos"
  add_foreign_key "guia_itens_arrecadacao", "guias"
  add_foreign_key "guia_itens_arrecadacao", "itens_arrecadacao"
  add_foreign_key "guias", "parcelas"
  add_foreign_key "parcelas", "debitos"
end
