class ItemArrecadacaoDecorator < ApplicationDecorator
  delegate_all

  def descricao
    "#{object.codigo} - #{object&.descricao}"
  end

  def valor
    h.number_to_currency(object.valor) if object.valor.present?
  end

  def tipo_taxa
    return '' if object.tipo_taxa.blank?
    I18n.t("activerecord.attributes.item_arrecadacao.tipos_taxa.#{object.tipo_taxa}")
  end
end