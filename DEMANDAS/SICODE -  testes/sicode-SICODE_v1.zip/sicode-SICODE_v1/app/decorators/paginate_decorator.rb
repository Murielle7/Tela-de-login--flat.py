class PaginateDecorator < Draper::CollectionDecorator
  delegate :current_page, :total_count, :total_pages, :per_page, :offset, :page, :limit_value
end