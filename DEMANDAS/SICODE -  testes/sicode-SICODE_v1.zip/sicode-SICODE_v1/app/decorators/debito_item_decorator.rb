class DebitoItemDecorator < ApplicationDecorator
  delegate_all

  def valor
    helpers.number_to_currency(object.valor)
  end

  def valor_atualizado
    helpers.number_to_currency(object.valor_atualizado) if object.valor_atualizado.present?
  end

  def descricao
    object.descricao
  end

  def valor_ref
    helpers.number_to_currency(object.valor_ref) if object.valor_ref.present?
  end

  def data_ref
    object.data_ref.strftime('%d/%m/%Y') if object.data_ref.present?
  end

  def data_atualizacao
    object.data_atualizacao.strftime('%d/%m/%Y') if object.data_atualizacao.present?
  end

  def juros
    helpers.number_to_currency(object.juros) if object.juros.present?
  end

  def multa
    helpers.number_to_currency(object.multa) if object.multa.present?
  end

  def correcao
    helpers.number_to_currency(object.correcao) if object.correcao.present?
  end

  def item_arrecadacao_nome
    object.item_arrecadacao.nome if object.item_arrecadacao.present?
  end
end