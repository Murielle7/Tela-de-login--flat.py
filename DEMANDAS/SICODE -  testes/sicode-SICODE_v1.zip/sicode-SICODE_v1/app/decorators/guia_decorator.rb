class GuiaDecorator < ApplicationDecorator
  delegate_all

  def valor
    h.number_to_currency(object.valor) if object.valor.present?
  end

  def data_vencimento
    object.data_vencimento.strftime('%d/%m/%Y') if object.data_vencimento.present?
  end

  def situacao
    I18n.t("activerecord.attributes.guia.situacoes.#{object.situacao}")
  end

  def numero
    object.numero.present? ? object.numero : 'Aguardando geração'
  end

  def debito_nome
    object&.parcela&.debito&.nome
  end

  def cpf
    object&.parcela&.debito&.cpf
  end

  def situacao_badge
    klass = case object.situacao
    when 'aguardando_pagamento'
      'bg-warning'
    when 'pago'
      'bg-success'
    when 'cancelado'
      'bg-danger'
    end
    "<span class='badge #{klass} rounded-pill'>#{situacao}</span>".html_safe
  end

  def guia_link_spg
    if object&.numero.present?
      h.link_to "https://projudi.tjgo.jus.br/GerarBoleto?PaginaAtual=2&numeroGuiaConsulta=#{object&.numero}", target: '_blank', class: 'btn btn-primary hstack gap-2' do
        %Q(<i class="fas fa-barcode fs-4"></i>
        <span class="vr"></span>
          Gerar Boleto).html_safe
      end
    end
  end

  def parcela_info
    return '' if object&.parcela.blank?
    return 'Parcela única' if object&.parcela&.debito&.parcelas&.count == 1
    "Parcela #{object&.parcela&.numero} de #{object&.parcela&.debito&.parcelas&.count}"
  end

  def valor_pago
    h.number_to_currency(object.valor_pago) if object.valor_pago.present?
  end

  def data_pagamento
    object.data_pagamento.strftime('%d/%m/%Y') if object.data_pagamento.present?
  end

  def tipo
    I18n.t("activerecord.attributes.guia.tipos.#{object.tipo}")
  end
end