class DebitosController < ApplicationController
  layout 'login'

  def index
    return unless params[:hash].present?

    @debito = Debito.find_by(hash_acesso: params[:hash])
    @debito = DebitoDecorator.new(@debito)
  end

  def show
    @debito = Debito.includes(:debito_itens).find_by(hash_acesso: params[:id])
    @debito = DebitoDecorator.new(@debito)
  end

  def create
    return redirect_to root_path, alert: 'Por favor informe o Hash de acesso' if params[:hash].blank?

    @debito = Debito.find_by(hash_acesso: params[:hash])

    if @debito.present?
      redirect_to debito_path(@debito.hash_acesso)
    else
      flash.now[:alert] = "Débito Hash: #{params[:hash]} não encontrado"
      render :index
    end
  end
end
