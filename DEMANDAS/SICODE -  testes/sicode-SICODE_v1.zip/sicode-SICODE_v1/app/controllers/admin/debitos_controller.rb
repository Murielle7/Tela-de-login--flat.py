module Admin
  class DebitosController < Admin::ApplicationController
    def index
      @debitos = Debito.search(search_params)
      @debitos = DebitoDecorator.decorate_collection(@debitos)

      respond_to do |format|
        format.html
        format.turbo_stream { render turbo_stream: turbo_stream.replace('debitos', partial: 'admin/debitos/debito', locals: { debitos: @debitos }) }
      end
    end

    def show
      @debito = Debito.find(params[:id])
      @debito = DebitoDecorator.decorate(@debito)
    end

    def new
      @debito = Debito.new
      @debito.debito_itens.build
    end

    def edit
      @debito = Debito.find(params[:id])
    end

    def create
      @debito = Debito.new(debito_params)

      if @debito.registrar
        redirect_to admin_debito_path(@debito), notice: 'Débito criado com sucesso'
      else
        flash.now[:alert] = 'Não foi possível criar o débito'
        render :new
      end
    end

    def update
      @debito = Debito.find(params[:id])

      if @debito.update(debito_params)
        redirect_to admin_debito_path(@debito), notice: 'Débito atualizado com sucesso'
      else
        flash.now[:alert] = 'Não foi possível atualizar o débito'
        render :edit
      end
    end

    def destroy
      @debito = Debito.find(params[:id])
      @debito.destroy

      respond_to do |format|
        format.html { redirect_to admin_debitos_path, notice: 'Débito removido com sucesso' }
        format.turbo_stream { render turbo_stream: turbo_stream.remove(@debito) }
      end
    end

    private

    def debito_params
      params.require(:debito).permit(:descricao, :nome, :cpf, :cnpj, :data_ref, :categoria_debito_id,
                                     :numero_grs, :numero_processo,
                                     debito_itens_attributes: [:id, :_destroy, :valor_ref, :descricao, :data_ref, :aplicar_correcao, :aplicar_juros, :aplicar_multa, :item_arrecadacao_id])
    end

    def search_params
      params.permit(:nome, :cpf, :cnpj, :situacao, :valor_ref, :data_ref, :data_vencimento, :data_atualizacao,
                    :categoria, :numero_grs, :numero_processo, :order, :page, :per)
    end
  end
end