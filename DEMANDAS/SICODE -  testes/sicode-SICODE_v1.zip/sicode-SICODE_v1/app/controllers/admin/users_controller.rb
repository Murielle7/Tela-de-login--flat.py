module Admin
  class UsersController < Admin::ApplicationController
    def index
      @users = User.order(params[:sort_by] || :id).page(params[:page])
      authorize @users
      respond_to do |format|
        format.html
        format.js
        format.turbo_stream { render turbo_stream: turbo_stream.replace('users', partial: 'admin/users/collection', locals: { users: @users }) }
      end
    end

    def show
      @user = User.find(params[:id])
      authorize @user
    end

    def new
      @user = User.new
      authorize @user
    end

    def create
      @user = User.new(user_params)
      authorize @user

      if @user.save
        redirect_to admin_users_path, notice: 'Usuário criado com sucesso'
      else
        flash.now[:alert] = 'Não foi possível criar o usuário'
        render :new
      end
    end

    def edit
      @user = User.find(params[:id])
      authorize @user
    end

    def update
      @user = User.find(params[:id])
      authorize @user

      if @user.update(user_params)
        redirect_to admin_users_path, notice: 'Usuário atualizado com sucesso'
      else
        flash.now[:alert] = 'Não foi possível atualizar o usuário'
        render :edit
      end
    end

    def destroy
      @user = User.find(params[:id])
      authorize @user
      @user.destroy

      redirect_to admin_users_path, notice: 'Usuário removido com sucesso'
    end

    private

    def user_params
      params.require(:user).permit(:email, :password, :password_confirmation, :role, :username, :nome, :cpf, :phone)
    end
  end
end