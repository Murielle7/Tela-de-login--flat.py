module  Admin
  class IndicadoresFinanceirosController < Admin::ApplicationController
    def index
      @indicadores_financeiros = IndicadorFinanceiro.all.order(params[:sort_by] || 'id desc').page(params[:page])
      @indicadores_financeiros = IndicadorFinanceiroDecorator.decorate_collection(@indicadores_financeiros)

      respond_to do |format|
        format.html
        format.js
        format.turbo_stream { render turbo_stream: turbo_stream.replace('indicadores_financeiros', partial: 'admin/indicadores_financeiros/indicador_financeiro', locals: { indicadores_financeiros: @indicadores_financeiros }) }
      end
    end

    def show
      @indicador_financeiro = IndicadorFinanceiro.find(params[:id])
      @indicador_financeiro = IndicadorFinanceiroDecorator.decorate(@indicador_financeiro)
    end

    def new
      @indicador_financeiro = IndicadorFinanceiro.new
    end

    def edit
      @indicador_financeiro = IndicadorFinanceiro.find(params[:id])
    end

    def create
      @indicador_financeiro = IndicadorFinanceiro.new(indicador_financeiro_params)

      if @indicador_financeiro.save
        redirect_to admin_indicadores_financeiros_path, notice: 'Indicador financeiro criado com sucesso'
      else
        flash.now[:alert] = 'Não foi possível criar o indicador financeiro'
        render :new
      end
    end

    def update
      @indicador_financeiro = IndicadorFinanceiro.find(params[:id])

      if @indicador_financeiro.update(indicador_financeiro_params)
        redirect_to admin_indicadores_financeiros_path, notice: 'Indicador financeiro atualizado com sucesso'
      else
        flash.now[:alert] = 'Não foi possível atualizar o indicador financeiro'
        render :edit
      end
    end

    def destroy
      @indicador_financeiro = IndicadorFinanceiro.find(params[:id])
      @indicador_financeiro.destroy

      respond_to do |format|
        format.html { redirect_to admin_indicadores_financeiros_path, notice: 'Indicador financeiro removido com sucesso' }
        format.turbo_stream { render turbo_stream: turbo_stream.remove(@indicador_financeiro) }
      end
    end

    private

    def indicador_financeiro_params
      params.require(:indicador_financeiro).permit(:nome, :descricao, :valor, :data_referencia, :tipo, :inicio,
                                                   :final, :percentual, :acumulado)
    end
  end
end
# https://projudi.tjgo.jus.br/GerarBoleto?PaginaAtual=2&numeroGuiaConsulta=21816930202

# adicionar numero de guia e numero de processo no debito