class GuiasController < ApplicationController
  layout 'login'
  before_action :set_debito
  before_action :set_parcela

  def show
    @guia = @parcela.guia
    if @guia.blank?
      redirect_to debito_path(@debito.hash_acesso), alert: 'Guia não encontrada.'
      return
    end
    @parcela.atualizar_guia if @guia.present? && @guia.data_vencimento < Date.current
    @debito = DebitoDecorator.new(@debito)
    begin
      ::GuiaService.new.consultar_guia([@guia])
    rescue StandardError => e
      puts e.message
    ensure
      @guia = GuiaDecorator.new(@parcela.guia)
    end
  end

  def create
    ok = @parcela.gerar_guia

    respond_to do |format|
      format.html do
        if ok
          redirect_to debito_parcela_guia_path(@debito.hash_acesso, @parcela, 1), notice: 'Guia gerada com sucesso.'
        else
          redirect_to debito_path(@debito.hash_acesso), alert: 'Erro ao gerar guia.'
        end
      end
      format.turbo_stream do
        if ok
          render turbo_stream: turbo_stream.replace("parcela-#{@parcela.id}", partial: 'parcelas/parcela',
                                                                              locals: { debito: @debito, parcela: @parcela })
        else
          render turbo_stream: turbo_stream.replace("parcela-#{@parcela.id}", partial: 'parcelas/parcela',
                                                                              locals: { debito: @debito, parcela: @parcela })
        end
      end
    end
  end

  private

  def set_debito
    @debito = Debito.find_by(hash_acesso: params[:debito_id])
  end

  def set_parcela
    @parcela = @debito.parcelas.ativas.find(params[:parcela_id])
  end
end
