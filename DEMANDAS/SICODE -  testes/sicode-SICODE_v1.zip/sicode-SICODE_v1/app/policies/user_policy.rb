class UserPolicy < ApplicationPolicy
  # class Scope < Scope
  # NOTE: Be explicit about which records you allow access to!
  # def resolve
  #   scope.all
  # end
  def index?
    true
  end

  def show?
    admin?
  end

  def new?
    admin?
  end

  def create?
    admin?
  end

  def update?
    admin?
  end

  def edit?
    admin?
  end

  def destroy?
    admin?
  end

  #  end
end
