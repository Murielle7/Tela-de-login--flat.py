# Número-índice de março de 2020: 5.348,49
# Número-índice de agosto de 2012: 3.512,04
# Fator de correção: 5.348,49 / 3.512,04 = 1,5229
# Valor corrigido: 1.000 x 1,5229 = R$ 1.522,90.
module Indices
  module Ipca


    def self.importar(ultimos: 0, data_inicial: nil, data_final: Date.current)
      # data_inicial = Date.new(2017, 1, 1)
      # data_final = Date.new(2023, 12, 1)

      ipca_service = BancoCentral::IpcaService.new
      if data_inicial.present? && data_final.present?
        ipca_service.por_periodo(data_inicial, data_final)
      else
        ultimos = 1 if ultimos.to_i.zero?
        ipca_service.ultimos(ultimos)
      end

      return unless ipca_service.res.status == 200

      ipca_service.parsed_response.each do |ipca|
        data = ipca['data'].to_date
        indicador = IndicadorFinanceiro.find_or_initialize_by(tipo: 'ipca', nome: "IPCA #{data.strftime('%m/%Y')}",
                                              inicio: data,
                                              final: data.end_of_month,
                                              percentual: true, ativo: true)
        indicador.valor = ipca['valor'].to_f
        indicador.save
      end
    end

    def self.periodo(inicio, final=Date.today)
      inicio = inicio.next_month.beginning_of_month
      final = (final - 1.month).end_of_month
      IndicadorFinanceiro.where(tipo: :ipca, inicio: inicio..final, final: inicio..final).order(:inicio).uniq
    end

    def self.indice_periodo(inicio, final=Date.today)
      ipcas = periodo(inicio, final)
      return 0 if ipcas.empty?

      i = ipcas.last.acumulado / ipcas.first.acumulado
      i / 100
    rescue => e
      Rails.logger.error "Erro ao calcular IPCA: #{e.message}"
      0
    end
  end
end