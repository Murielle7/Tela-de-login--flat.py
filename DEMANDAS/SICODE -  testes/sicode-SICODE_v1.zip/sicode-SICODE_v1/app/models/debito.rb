class Debito < ApplicationRecord
  has_many :debito_itens, dependent: :destroy
  has_many :parcelas, dependent: :destroy
  belongs_to :categoria_debito

  validates :nome, :valor_ref, presence: true
  validate :formatocpfcnpj

  enum situacao: { aguardando_pagamento: 'aguardando_pagamento', pago: 'pago',
                   vencido: 'vencido', protesto: 'protesto', protesto_pago: 'protesto_pago', cancelado: 'cancelado', divida_ativa: 'divida_ativa' }

  scope :em_aberto, -> { where(situacao: [:aguardando_pagamento, :vencido]) }

  before_save :sanitize_cpf_cnpj
  after_save :atualizar, unless: -> { data_atualizacao == Date.current}

  accepts_nested_attributes_for :debito_itens, reject_if: :all_blank , allow_destroy: true

  def registrar
    return false if debito_itens.empty?
    return false unless self.valid?

    self.hash_acesso = SecureRandom.hex(10)
    debito_itens.each do |debito_item|
      debito_item.atualizar_valores
    end
    self.data_atualizacao = Date.current
    self.situacao = :aguardando_pagamento
    self.valor_ref = debito_itens.sum(:valor_ref)
    self.valor_atualizado = debito_itens.sum(:valor_atualizado)
    self.data_ref = Date.current
    self.data_vencimento = Date.current + 30.days
    self.save
  end

  def atualizar
    debito_itens.each do |debito_item|
      debito_item.atualizar_valores
    end
    self.data_atualizacao = Date.current
    self.valor_atualizado = debito_itens.sum(:valor_atualizado)
    self.save
  end

  def atualizar_valor
    update(valor_atualizado: debito_itens.sum(:valor_atualizado))
  end

  def parcelar(data_primeira_parcela:, numero_parcelas:, valor_primeira_parcela: 0.0)
    atualizar_valor
    atualizar if data_atualizacao < Date.current
    Parcelamento.new(debito: self, data_primeira_parcela: data_primeira_parcela, numero_parcelas: numero_parcelas, valor_primeira_parcela: valor_primeira_parcela)
  rescue => e
    false
  end

  def confirmar_parcelamento
    parcelas.map(&:confirmar)
  end

  def negar_parcelamento
    self.transaction do
      self.parcelas.each  do |parcela|
        raise ActiveRecord::Rollback if parcela.guia.present?
        parcela.destroy
      end
    end
  end

  def self.search(params={})
    debitos = Debito.all
    debitos = debitos.where("nome ilike ?", "%#{params[:nome]}%") if params[:nome].present?
    debitos = debitos.where("cpf ilike ?", "%#{params[:cpf]}%") if params[:cpf].present?
    debitos = debitos.where("cnpj ilike ?", "%#{params[:cnpj]}%") if params[:cnpj].present?
    debitos = debitos.where("situacao = ?", params[:situacao]) if params[:situacao].present?
    debitos = debitos.where("valor_ref = ?", params[:valor_ref]) if params[:valor_ref].present?
    debitos = debitos.where("data_ref = ?", params[:data_ref]) if params[:data_ref].present?
    debitos = debitos.where("data_vencimento = ?", params[:data_vencimento]) if params[:data_vencimento].present?
    debitos = debitos.where("data_atualizacao = ?", params[:data_atualizacao]) if params[:data_atualizacao].present?
    debitos = debitos.where("categoria = ?", params[:categoria]) if params[:categoria].present?
    debitos = debitos.where("hash_acesso = ?", params[:hash_acesso]) if params[:hash_acesso].present?
    debitos = debitos.order(params[:order]) if params[:order].present?
    debitos = debitos.page(params[:page]).per(params[:per])
    debitos
  end

  private

  def sanitize_cpf_cnpj
    self.cpf = cpf.gsub(/[^0-9]/, '') if cpf.present?
    self.cnpj = cnpj.gsub(/[^0-9]/, '') if cnpj.present?
  end

  def formatocpfcnpj
    if cpf.present?
      errors.add(:cpf, 'CPF inválido') unless CPF.valid?(cpf)
    end

    if cnpj.present?
      errors.add(:cnpj, 'CNPJ inválido') unless CNPJ.valid?(cnpj)
    end
  end
end
