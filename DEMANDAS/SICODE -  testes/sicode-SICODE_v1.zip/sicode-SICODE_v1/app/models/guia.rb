class Guia < ApplicationRecord
  belongs_to :parcela, dependent: :destroy
  has_one :debito, through: :parcela
  has_many :guia_itens_arrecadacao

  SERIE = '02'

  validates :valor, :data_vencimento, presence: true
  validates_uniqueness_of :numero, scope: :ativa, on: :update
  validates_uniqueness_of :parcela_id, scope: :ativa, if: :ativa?

  before_save :gerar_numero
  before_save :atualiza_valor

  enum situacao: %i[aguardando_pagamento paga cancelada]
  enum tipo: %i[unica parcela]

  scope :ativas, -> { where(ativa: true) }
  scope :aguardando_pagamento, -> { where(situacao: :aguardando_pagamento) }

  def valor_total
    guia_itens_arrecadacao.sum(:valor)
  end

  def atualizar_valor
    parcela.atualizar_guia
  end

  def self.search(params)
    guias = includes(parcela: :debito).all
    guias = guias.where('numero = ?', params[:numero]) if params[:numero].present?
    guias = guias.where('guias.data_vencimento = ?', params[:data_vencimento]) if params[:data_vencimento].present?
    guias = guias.where('guias.valor = ?', params[:valor]) if params[:valor].present?
    guias = guias.where('guias.situacao = ?', params[:situacao]) if params[:situacao].present?
    guias = guias.where('guias.tipo = ?', params[:tipo]) if params[:tipo].present?
    guias = guias.where('guias.ativa = ?', params[:ativa]) if params[:ativa].present?
    guias = guias.joins(:debito).where('debitos.cpf = ?', params[:cpf]) if params[:cpf].present?
    guias = guias.joins(:debito).where('debitos.nome ilike ?', "#{params[:nome]}%") if params[:nome].present?
    guias.page(params[:page] || 1).per(params[:per_page] || 10).order(params[:sort_by] || :id)
  end

  # enum to select field
  def self.situacoes_for_select
    situacoes.map { |situacao, value| [I18n.t("activerecord.attributes.guia.situacoes.#{situacao}"), value] }
  end

  # enum to select field
  def self.tipos_for_select
    tipos.map { |tipo, value| [I18n.t("activerecord.attributes.guia.tipos.#{tipo}"), value] }
  end

  # private

  def atualiza_valor
    self.valor = valor_total
  end

  def gerar_numero
    return if numero.present?

    ultimo_id = Guia.maximum(:id) || 0
    numero = format('%08d', ultimo_id + 1)
    soma = 0
    i = 1
    while i <= numero.length
      soma += (numero[i - 1].to_i * (10 - i))
      i += 1
    end
    modulo = soma - ((soma / 11).abs * 11)
    modulo = (11 - modulo) if modulo > 1
    digito = modulo.to_s
    numero = numero + digito + SERIE
    self.numero = numero
  end

  def registrar_saj
    saj = ::GuiaService.new
    saj.inserir_guia(self)
    saj
  end
end
