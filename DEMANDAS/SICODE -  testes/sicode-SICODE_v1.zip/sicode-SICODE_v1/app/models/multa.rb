class Multa
  attr_reader :valor, :valor_original ,:dias, :indice

  def initialize(options: {})
    @valor_original = options.fetch(:valor_original, 0.0)
    @valor = 0.0
    @indice = options.fetch(:indice, 0.0033)
    @data_ref = options.fetch(:data_ref, Date.today).blank? ? Date.today : options.fetch(:data_ref, Date.today)
    @data_final = options.fetch(:data_final, Date.today).blank? ? Date.today : options.fetch(:data_final, Date.today)
    @dias = options.fetch(:dias, dias_atraso).blank? ? dias_atraso : options.fetch(:dias, dias_atraso)
    @indice_max = options.fetch(:indice_max, 0.2)
    calcular
  end

  def calcular
    return if dias.zero? || indice.zero?

    indice_total = indice * dias
    indice_total = @indice_max  if indice_total > @indice_max
    @valor = valor_original *  indice_total
  end

  def dias_atraso
    (@data_final - @data_ref).to_i
  end

end