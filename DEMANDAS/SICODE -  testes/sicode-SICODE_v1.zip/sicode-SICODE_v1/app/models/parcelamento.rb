class Parcelamento
  attr_reader :debito, :numero_parcelas, :valor_primeira_parcela, :data_primeira_parcela

  def initialize(debito: nil, numero_parcelas: 1, valor_primeira_parcela: 0.0, data_primeira_parcela: Date.today)
    @debito = debito
    @numero_parcelas = numero_parcelas.to_i
    @valor_primeira_parcela = valor_primeira_parcela.to_f
    @data_primeira_parcela = data_primeira_parcela.try(:to_date)
    parcelar
  end

  def parcelar
    return create_parcela(numero_parcela: 1, valor: debito.valor_atualizado, data_vencimento: data_primeira_parcela) if numero_parcelas == 1

    if debito.valor_atualizado.zero?
      raise ArgumentError, 'Valor total do parcelamento não pode ser zero'
    end

    # valor primeira parcela = 5% do valor total, o valor informado ou R$ 200, o que for maior
    valor_primeira = [debito.valor_atualizado.to_f * 0.05, 200, @valor_primeira_parcela.to_f].max
    valor_restante = debito.valor_atualizado - valor_primeira
    create_parcela(numero_parcela: 1, valor: valor_primeira, data_vencimento: data_primeira_parcela)
    parcelas(quantidade: numero_parcelas - 1, valor: valor_restante, data_vencimento: data_primeira_parcela + 1.month, inicio: 2)
  end

  def parcelas(quantidade:, valor:, data_vencimento:, inicio: 1)
    quantidade = 39 if quantidade.to_i > 39
    valor_parcela = valor.to_f / quantidade
    if valor_parcela < 200 && quantidade > 1
      # Se o valor da parcela for menor que 200, dividir o valor por 200 pra pegar o número de parcelas
      quantidade = (valor / 200.0).to_i
      valor_parcela = valor.to_f / quantidade
    end
    quantidade.times do |n|
      create_parcela(numero_parcela: n + inicio, valor: valor_parcela.round(2), data_vencimento: data_vencimento + n.months)
    end
  end

  def create_parcela(numero_parcela:, valor:, data_vencimento:)
    Parcela.create(debito: debito, numero: numero_parcela, valor_ref: valor, valor: valor, data_ref: debito.data_atualizacao, data_vencimento: data_vencimento, situacao: :aguardando_confirmacao)
  end
end