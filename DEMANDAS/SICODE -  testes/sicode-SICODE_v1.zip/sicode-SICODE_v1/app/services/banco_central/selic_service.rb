module BancoCentral
  class SelicService
    include BancoCentral
    attr_reader :res

    # bcdata.sgs.1178 Anualizada diária
    # bcdata.sgs.4189 Anualizada mensal
    # bcdata.sgs.11 percentual ao dia
    # bcdata.sgs.4390 acumulada no mês

    def initialize
      @url_base = 'https://api.bcb.gov.br/'
      @conn = Faraday.new(@url_base)
      @res = nil
      @serie = 'bcdata.sgs.4390'
    end

  end
end
