module BancoCentral
  class IpcaService
    include BancoCentral
    attr_reader :res

    # bcdata.sgs.11427

    def initialize
      @url_base = 'https://api.bcb.gov.br/'
      @conn = Faraday.new(@url_base)
      @res = nil
      @serie = 'bcdata.sgs.11427'
    end

  end
end
