class GuiaService
  # TODO: conectar com a API do Sistema de Guias

  attr_reader :status, :message, :errors, :retorno

  def initialize
    @base_url = ENV['URL_API_GUIAS'] || ENV['OPENSHIFT_URL_API_GUIAS']
    @status = nil
    @message = nil
    @retorno = []
    @errors = []
    @parsed_response = {}
  end

  # - inserir guia
  # guia_params = {
  #    'numeroGuia': guia.numero,
  #    'dataEmissao': guia.created_at.to_date,
  #    'dataVencimento': guia.data_vencimento,
  #    'tipoGuia': guia.tipo,
  #    'valor': guia.valor,
  #    'cpf': (guia.debito.cpf || guia.debito.cnpj),
  #     'nomePagador': guia.debito.nome,
  #     'listaGuiaItemSpg': guia.guia_itens_arrecadacao.map do |item|
  #       {
  #         'codigoArrecadacao': item&.item_arrecadacao&.codigo_arrecadacao,
  #        'valorItem': item.valor
  #      }
  #    end
  #  }
  def inserir_guia(guia)
    return if guia.situacao == 'paga'
    return unless guia.ativa?
    # return unless guia.valor.try(:to_d) > 0.0
    return if guia.numero.blank?
    return if guia.data_vencimento.blank?
    return if guia.lancado_spg?

    https, request = build_connection(url: "#{@base_url}/incluir_guia_financeira", method: :post)

    options = {
      numeroGuia: guia.numero,
      dataEmissao: guia.created_at.to_date,
      dataVencimento: guia.data_vencimento,
      tipoGuia: guia.tipo,
      valor: guia.valor,
      cpf: guia.cpf || guia.cnpj,
      nomePagador: guia.identificacao_sacado,
      listaGuiaItemSpg: guia.guia_itens_arrecadacao.map do |item|
        {
          codigoArrecadacao: item&.item_arrecadacao&.codigo_arrecadacao,
          valorItem: item.valor
        }
      end
    }

    request.body = JSON.dump(options)
    response = https.request(request)

    @parsed_response = JSON.parse(response.read_body)
    @status = @parsed_response['status']

    if res.status == 201 # Created
      @status = :ok
      @message = @parsed_response.fetch('message', 'Guia inserida com sucesso')
      guia.update(lancado_spg: true)
    else
      @status = :error
      @message = @parsed_response.fetch('error', 'Erro ao inserir guia')
      @errors = res.body
    end
  rescue JSON::ParserError => e
    @status = :error
    @message = 'Erro ao inserir guia'
    @errors = e
  end

  # - consultar guia
  # campos de retorno:
  # - idGuiaSpg, numeroGuia, nomePagador, numeroBoleto, valor, urlPdfBoleto, dataEmissao, dataEmissaoBoleto, dataVencimento, tipoGuia, dataReferenciaDecendio, infoInternet, infoLocalCertidao, listaGuiaItemSpg, cpf

  def consultar_guia(guias = [])
    # consultar guia na API
    # post para https://portal-corregedoria.tjgo.jus.br/api/saj/listar_guias
    # com os numeros das guias

    https, request = build_connection(url: "#{@base_url}/listar_guias", method: :post)
    request.body = JSON.dump(guias.map(&:numero))

    response = https.request(request)
    @parsed_response = JSON.parse(response.read_body)
    @status = @parsed_response['status']

    if @status == 200
      @message = @parsed_response.fetch('message', 'Guia consultada com sucesso')
      @retorno = @parsed_response.fetch('retorno', [])
    else
      @status = :error
      @message = @parsed_response.fetch('error', 'Erro ao consultar guia')
    end
  rescue JSON::ParserError => e
    @status = :error
    @message = 'Erro ao inserir guia'
    @errors = e
  end

  def consultar_pagamento(guias = [])
    numeros = guias.map(&:numero)
    https, request = build_connection(url: "#{@base_url}/listar_pagamentos", method: :post)

    request.body = JSON.dump(guias.map(&:numero))

    response = https.request(request)
    @parsed_response = JSON.parse(response.read_body)
    @status = @parsed_response['status']

    if @status == 200
      @message = @parsed_response.fetch('message', 'Pagamento consultado com sucesso')
      @retorno = @parsed_response.fetch('retorno', [])
      @retorno.each do |retorno|
        next if retorno == {}

        guia = guias.find { |g| g.numero == "#{retorno['numeroGuia']}#{retorno['serieGuia']}" }
        next if guia.nil?
        next if Date.parse(retorno['dataPagamento']) < guia.created_at.to_date
        next if retorno['valorPago'].try(:to_f) < guia.valor.to_f

        atualizar_guia_local(guia:, retorno:)
      end
    else
      @status = :error
      @message = @parsed_response.fetch('message', 'Erro ao consultar pagamento')
    end
  rescue JSON::ParserError => e
    @status = :error
    @message = 'Erro ao inserir guia'
    @errors = e
  end

  def atualizar_guia_local(guia:, retorno:)
    return unless guia.situacao == 'aguardando_pagamento'
    return unless @status == '200'
    return if @retorno.empty?

    guia.update(situacao: :paga, valor_pago: retorno['valorPago'], data_pagamento: Date.parse(retorno['dataPagamento']))
  end

  def atualizar_pagamentos
    guias = ::Guia.aguardando_pagamento
    consultar_pagamento(guias)
  end

  def build_connection(url: nil, method: :post)
    uri = URI(url)

    https = Net::HTTP.new(uri.host, uri.port)
    https.use_ssl = true

    request = Net::HTTP::Post.new(uri)
    request['Content-Type'] = 'application/json'

    guia_token = ENV['API_GUIAS_TOKEN'] || ENV['OPENSHIFT_API_GUIAS_TOKEN']
    request['Authorization'] = "Bearer #{guia_token}"
    [https, request]
  end
end
