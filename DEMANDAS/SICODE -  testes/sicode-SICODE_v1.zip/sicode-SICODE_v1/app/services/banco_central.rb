module BancoCentral

  # bcdata.sgs.1178 Anualizada diária
  # bcdata.sgs.4189 Anualizada mensal
  # bcdata.sgs.11 percentual ao dia
  # bcdata.sgs.4390 acumulada no mês

    def ultimos(quantidade = 10)
      @res = @conn.get do |req|
        req.url "#{@url_base}dados/serie/#{@serie}/dados/ultimos/#{quantidade}?formato=json"
        req.headers['Content-Type'] = 'application/json'
      end
    end

    # &dataInicial=01/01/2010&dataFinal=31/12/2016
    def por_periodo(data_inicio, data_fim)
      data_inicial = data_inicio.is_a?(Date) ? data_inicio : data_inicio.strftime('%d/%m/%Y')
      data_final = data_fim.is_a?(Date) ? data_fim : data_fim.strftime('%d/%m/%Y')
      @res = @conn.get do |req|
        req.url "#{@url_base}dados/serie/#{@serie}/dados/?formato=json&dataInicial=#{data_inicial}&dataFinal=#{data_final}"
        req.headers['Content-Type'] = 'application/json'
      end
    end

    def parsed_response
      return [] if res.nil?
      return JSON.parse(res.body) if res.respond_to?(:body)

      JSON.parse(res)
    end

end