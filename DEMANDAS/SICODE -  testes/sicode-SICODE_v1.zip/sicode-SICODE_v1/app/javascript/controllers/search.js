import { Controller } from "@hotwired/stimulus"

export default class Search extends Controller {
  static targets = [ "input", "results" ]

  connect() {
    console.log("Search controller connected")
  }

  search() {
    console.log("Searching for", this.inputTarget.value)
    // Fetch search results from the server
    fetch(`/search?query=${this.inputTarget.value}`, { headers: { accept: "application/json" } })
      .then(response => response.json())
      .then((data) => {
        console.log(data)
        this.resultsTarget.innerHTML = data.results
      })
  }
}