import select2 from 'select2';

function makeAutoComplete(i, e) {
  var input = $(e);
  var multiple = input.data('multiple');
  if (multiple === true) {
    input.val(input.data('init-value'));
    input.trigger('change');
  }
  input.select2({
    placeholder: input.data('placeholder'),
    width: 'resolve',
    multiple: multiple,
    selectOnBlur: true,
    ajax: {
      dataType: 'json',
      quietMillis: 500,
      data: function (params) {
        return {
          query: params.term, // search term
          page: params.page,
          per: input.data("max-results")
        };
      },
      processResults: function (data, params) {
        params.page = params.page || 1;
        return {
          results: data,
          pagination: {
            more: (params.page * 10) < data.count_filtered
          }
        };
      }
    }
  });

};


export function enableSelect2() {

  $("select.selectable").select2(
    {
      allowClear: true,
      placeholder: "Digite para pesquisar...",
      width: 'resolve',
      selectOnBlur: true
    });
};


export function enableAutoComplete() {
  $('.autocompletable').each(function (i, e) {
    makeAutoComplete(i, e)
  });

  $('.tokenable').each(function (i, e) {
    makeAutoComplete(i, e)
  });

  $('.external-select').each(function (i, e) {
    makeExternalSelect(i, e)
  });
};

