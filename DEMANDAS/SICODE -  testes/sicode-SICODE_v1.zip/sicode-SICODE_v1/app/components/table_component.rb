# frozen_string_literal: true

class TableComponent < ViewComponent::Base
  def initialize(collection: [], fields: [], sort_fields: nil, search_fields: nil)
    @collection = collection
    @fields = fields
    @sort_fields = sort_fields
    @search_fields = search_fields
  end

  def render?
    return true
    @collection&.any?
  end

  def table_name
    @collection.first.class.name.underscore
  end

  def translate_field(field)
    I18n.t("activerecord.attributes.#{table_name}.#{field}")
  end

  def field_value(record, field)
    return record.send(field).strftime('%d/%m/%Y') if record.send(field).is_a?(Date)
    return record.send(field).strftime('%d/%m/%Y %H:%M') if record.send(field).is_a?(Time)
    return record.send(field).strftime('%d/%m/%Y %H:%M:%S') if record.send(field).is_a?(DateTime)
    return number_to_currency(record.send(field)) if record.send(field).is_a?(Numeric)
    return (record.send(field) ? 'Sim' : 'Não') if record.send(field).is_a?(TrueClass) || record.send(field).is_a?(FalseClass)

    record.send(field)
  end

end
