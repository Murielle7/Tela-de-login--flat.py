# frozen_string_literal: true

class ActionButtonComponent < ViewComponent::Base
  def initialize(url:, title:, klass: 'info', turbo: false, texto: nil, icon_class: nil)
    @url = url
    @klass = klass
    @title = title
    @turbo = turbo
    @texto = texto
    @icon_class = icon_class
  end

  def method
    return :delete if @klass == 'danger'

    :get
  end

  def data
    return {} unless @klass == 'danger'

    data = { confirm: 'Você tem certeza?' } if @klass == 'danger'
    data.merge!({ form: { turbo: 'false' } }) unless @turbo
    data
  end

  def icon_class
    return @icon_class if @icon_class
    return 'fas fa-trash' if @klass == 'danger'
    return 'fas fa-edit' if @klass == 'warning'
    return 'fas fa-add' if @klass == 'add'
    return 'fas fa-refresh' if @klass == 'refresh'
    return 'fas fa-chevron-left' if @klass == 'back'

    'fas fa-eye'
  end

  def link_class
    return 'btn btn-danger' if @klass == 'danger'
    return 'btn btn-warning' if @klass == 'warning'
    return 'btn btn-success hstack gap-2 mb-3' if @klass == 'add'
    return 'btn btn-info hstack gap-2 mb-3' if @klass == 'refresh'
    return 'btn btn-secondary  hstack gap-2 ' if @klass == 'back'

    'btn btn-info'
  end

  def texto
    "<span class='vr'></span>".html_safe + @texto if @texto
  end
end
