# frozen_string_literal: true

class FilterComponent < ViewComponent::Base
  def initialize(path:, method: 'get', order_fields: nil, search_fields: [])
    @path = path
    @method = method
    @order_fields = order_fields || default_order_fields
    @search_fields = search_fields
  end

  def default_order_fields
    [['Data de criação', 'created_at'], ['Data de atualização', 'updated_at']]
  end

end
