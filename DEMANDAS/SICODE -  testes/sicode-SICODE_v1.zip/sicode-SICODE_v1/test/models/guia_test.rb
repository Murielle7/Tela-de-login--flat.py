require "test_helper"

class GuiaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
