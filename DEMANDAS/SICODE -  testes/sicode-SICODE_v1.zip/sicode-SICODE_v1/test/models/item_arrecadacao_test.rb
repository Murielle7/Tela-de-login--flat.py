require "test_helper"

class ItemArrecadacaoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
