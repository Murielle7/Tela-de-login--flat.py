require 'test_helper'

class JuroTest < ActiveSupport::TestCase
  def setup
    @options = {
      valor_original: 100.0,
      valor: 120.0,
      dias: 30,
      indice: 0.05,
      data_ref: Date.today,
      data_final: Date.today + 30.days
    }
    @juro = Juro.new(options: @options)
  end

  test 'initialize sets instance variables correctly' do
    assert_equal 100.0, @juro.instance_variable_get(:@valor_original)
    assert_equal 120.0, @juro.instance_variable_get(:@valor)
    assert_equal 30, @juro.instance_variable_get(:@dias)
    assert_equal 0.05, @juro.instance_variable_get(:@indice)
    assert_equal Date.today, @juro.instance_variable_get(:@data_ref)
    assert_equal Date.today + 30.days, @juro.instance_variable_get(:@data_final)
  end

  test 'calcular calculates the correct result' do
    # Add your assertions here to test the calcular method
  end
end