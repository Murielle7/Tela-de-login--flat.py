FactoryBot.define do
  factory :debito do
    nome { "MyString" }
    cpf { Faker::CPF.numeric }
    cnpj { '' }
    association :categoria_debito, factory: [:categoria_debito, :custas_finais]
    situacao { "aguardando_pagamento" }
    processo { "MyString" }
    data_ref { "2024-04-09" }
    data_vencimento { "2024-04-09" }
    hash_acesso { "MyString" }
    valor_ref { "9.99" }
    valor_atualizado { "9.99" }
    data_atualizacao { "2024-04-09" }
    descricao { "MyText" }
  end
end
