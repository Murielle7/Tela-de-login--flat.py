FactoryBot.define do
  factory :debito_item do
    debito { nil }
    valor_ref { "9.99" }
    valor_atualizado { "9.99" }
    data_ref { "2024-04-09" }
    data_atualizacao { "2024-04-09" }
    correcao { "9.99" }
    juros { "9.99" }
    multa { "9.99" }
    descricao { "MyText" }
  end
end
