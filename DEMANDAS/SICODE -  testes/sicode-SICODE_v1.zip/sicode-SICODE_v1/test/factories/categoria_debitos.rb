FactoryBot.define do
  factory :categoria_debito do
    nome { "MyString" }
    ativo { true }
    aplicar_correcao { false }
    aplicar_juros { false }
    aplicar_multa { false }

    trait :com_correcao do
      aplicar_correcao { true }
    end

    trait :com_juros do
      aplicar_juros { true }
    end

    trait :com_multa do
      aplicar_multa { true }
    end

    trait :debito_folha do
      nome { 'Ressarcimento de Débitos da Folha' }
      aplicar_correcao { true }
      aplicar_juros { false }
      aplicar_multa { false }
    end

    trait :custas_finais do
      nome { 'Custas Finais Protestadas' }
      aplicar_correcao { false }
      aplicar_juros { true }
      aplicar_multa { true }
    end

  end
end
