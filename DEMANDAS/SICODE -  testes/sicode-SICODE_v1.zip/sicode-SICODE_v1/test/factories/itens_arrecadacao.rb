FactoryBot.define do
  factory :item_arrecadacao do
    nome { "MyString" }
    ativo { true }
    codigo_arrecadacao { "MyString" }
    tipo_taxa { 1 }
    percent_emolumento { 1.5 }
    detalhes { "MyText" }
    data_inicio_vigencia { "2020-04-01" }
    data_fim_vigencia { "2099-12-31" }

    trait :fundesp do
      nome { "Fundesp" }
      codigo_arrecadacao { "5045" }
      tipo_taxa { 1 }
    end

    trait :multa do
      nome { "Fundesp" }
      codigo_arrecadacao { "5244" }
      tipo_taxa { 3 }
    end

    trait :juros do
      nome { "Juros" }
      codigo_arrecadacao { "5263" }
      tipo_taxa { 3 }
    end

    trait :diferenca_debito do
      nome { "Diferença de Débito" }
      codigo_arrecadacao { "5203" }
      tipo_taxa { 6 }
    end
  end

end
