require 'test_helper'

class IndicadorFinanceiroDecoratorTest < Draper::TestCase
end
