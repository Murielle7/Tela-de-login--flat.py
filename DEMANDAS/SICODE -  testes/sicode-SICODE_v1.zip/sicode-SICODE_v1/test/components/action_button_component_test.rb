# frozen_string_literal: true

require "test_helper"

class ActionButtonComponentTest < ViewComponent::TestCase
  def test_component_renders_something_useful
    # assert_equal(
    #   %(<span>Hello, components!</span>),
    #   render_inline(ActionButtonComponent.new(message: "Hello, components!")).css("span").to_html
    # )
  end
end
