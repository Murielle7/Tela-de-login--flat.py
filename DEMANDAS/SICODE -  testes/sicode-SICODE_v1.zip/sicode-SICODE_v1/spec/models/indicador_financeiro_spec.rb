require 'rails_helper'

RSpec.describe IndicadorFinanceiro, type: :model do
  context 'validations' do
    it { should validate_presence_of(:valor) }
    it { should validate_presence_of(:inicio) }
    it { should validate_presence_of(:final) }
  end

  context 'enum' do
    it { should define_enum_for(:tipo).backed_by_column_of_type(:string).with_values(selic: 'selic') }
  end

  context 'public methods' do
    let!(:indicador_selic_01_2017) { FactoryBot.create(:indicador_financeiro, tipo: 'selic', valor: 1, inicio: Date.new(2017,1,1), final: Date.new(2017,1,31)) }
    let!(:indicador_selic_02_2017) { FactoryBot.create(:indicador_financeiro, tipo: 'selic', valor: 2, inicio: Date.new(2017,2,1), final: Date.new(2017,2,28)) }
    let!(:indicador_selic_03_2017) { FactoryBot.create(:indicador_financeiro, tipo: 'selic', valor: 1, inicio: Date.new(2017,3,1), final: Date.new(2017,3,31)) }
    let!(:indicador_selic_04_2017) { FactoryBot.create(:indicador_financeiro, tipo: 'selic', valor: 2, inicio: Date.new(2017,4,1), final: Date.new(2017,4,30)) }

    # selic considera o proximo mês à partir da data inicial e
    # o mês anterior à data final
    it 'selic_periodo' do
      expect(IndicadorFinanceiro.selic_periodo(Date.new(2017, 1, 1), Date.new(2017, 3, 20))).to eq([indicador_selic_02_2017])
    end

    # para o indice selic_periodo, o valor é a soma dos indices do periodo + 1% do mês corrente
    it '#indice_selic_periodo' do
      expect(IndicadorFinanceiro.indice_selic_periodo(Date.new(2017, 1, 1), Date.new(2017, 4, 1))).to eq(4.0)
    end
  end

  context 'private methods' do
    let!(:indicador_selic) { FactoryBot.create(:indicador_financeiro, valor: 1.0, inicio: Date.new(2017, 1, 1), final: Date.new(2017, 1, 31)) }
    it 'validates referencia_overlap' do
      indicador = IndicadorFinanceiro.new(tipo: :selic, valor: 1, inicio: Date.new(2017, 1, 15), final: Date.new(2017, 1, 31))
      indicador.valid?
      expect(indicador.errors[:base]).to include('Referência já cadastrada')
    end
  end
end
