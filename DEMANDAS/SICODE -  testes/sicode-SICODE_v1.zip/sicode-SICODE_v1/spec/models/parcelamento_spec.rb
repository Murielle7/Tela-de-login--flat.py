require 'rails_helper'

RSpec.describe Parcelamento do
  let!(:debito) { FactoryBot.create(:debito, valor_atualizado: 10_000) }
  let!(:debito_item) { FactoryBot.create(:debito_item, debito: debito, valor_ref: 10_000, valor_atualizado: 10_000) }


  describe '#initialize' do
    it 'creates parcelas' do
      expect(debito.parcelas.count).to eq(0)
      Parcelamento.new(debito: debito, numero_parcelas: 1)
      expect(debito.parcelas.count).to eq(1)
    end
  end

  describe '#parcelar' do

    describe 'when numero_parcelas is 1' do
      before do
        Parcelamento.new(debito: debito, numero_parcelas: 1)
      end

      it 'creates one parcela' do
        expect(debito.parcelas.count).to eq(1)
      end

      it 'creates parcela with valor_ref equal to debito.valor_atualizado' do
        expect(debito.parcelas.first.valor_ref).to eq(debito.valor_atualizado)
      end
    end

    # valor minimo da parcela: 200
    # primeira parcela = 5% do valor total ou 200, o que for maior

    describe 'when numero_parcelas is greater than 1' do
      describe 'when first parcela has differente value' do
        before do
          allow(Indices::Selic).to receive(:indice_periodo).and_return(1.0)
          allow(Indices::Ipca).to receive(:indice_periodo).and_return(1.0)
          Parcelamento.new(debito: debito, numero_parcelas: 3, valor_primeira_parcela: 3_000)
        end

        it 'creates three parcelas' do
          expect(debito.parcelas.count).to eq(3)
        end

        it 'creates first parcela with valor_ref equal to valor_primeira_parcela' do
          expect(debito.parcelas.first.valor_ref).to eq(3_000)
        end

        it 'creates second parcela with valor_ref equal to 3_500' do
          expect(debito.parcelas.second.valor_ref).to eq(3_500)
        end

        it 'the first parcela has number equal to 1' do
          expect(debito.parcelas.first.numero).to eq(1)
        end

        it 'the second parcela has number equal to 2' do
          expect(debito.parcelas.second.numero).to eq(2)
        end
      end

      describe 'when all parcelas have the same value' do
        before do
          Parcelamento.new(debito: debito, numero_parcelas: 5)
        end

        it 'creates five parcelas' do
          expect(debito.parcelas.count).to eq(5)
        end

        it 'creates first parcela with valor_ref equal to 2_000' do
          expect(debito.parcelas.first.valor_ref).to eq(2_000)
        end

        it 'creates second parcela with valor_ref equal to 2_000' do
          expect(debito.parcelas.second.valor_ref).to eq(2_000)
        end
      end
    end
  end
end