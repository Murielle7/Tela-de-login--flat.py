require 'rails_helper'

RSpec.describe Parcela, type: :model do
  describe 'associations' do
    it { should belong_to(:debito) }
    it { should have_one(:guia) }
  end

  describe 'validations' do
    it { should validate_presence_of(:valor_ref) }
    it { should validate_presence_of(:data_vencimento) }
  end

  describe 'gerar_guia' do
    let!(:categoria_debito) { FactoryBot.create(:categoria_debito, aplicar_correcao: true, aplicar_juros: true, aplicar_multa: true) }
    let!(:debito) { FactoryBot.create(:debito, categoria_debito: categoria_debito) }
    let!(:fundesp) { FactoryBot.create(:item_arrecadacao, :fundesp) }
    let!(:parcela) { FactoryBot.create(:parcela, debito: debito, valor_ref: 1000.0,
                                        valor: 1000.0, data_atualizacao: Date.new(2024, 1, 1),
                                        data_vencimento: Date.new(2024, 1, 1) ) }
    before do
      allow(Indices::Selic).to receive(:indice_periodo).and_return(1.0)
      allow(Indices::Ipca).to receive(:indice_periodo).and_return(1.0)
      Timecop.freeze(Date.new(2024, 4, 1))
      parcela.gerar_guia
    end

    it 'cria guia' do
      expect(parcela.guia).to be_present
    end

    it 'atualiza situacao' do
      expect(parcela.situacao).to eq('aguardando_pagamento')
      expect(parcela.guia.situacao).to eq('aguardando_pagamento')
    end

    it 'tem um item de arrecadação fundesp' do
      expect(parcela.guia.guia_itens_arrecadacao.map(&:item_arrecadacao_id)).to include(fundesp.id)
    end

    it 'valor da guia' do
      expect(parcela.guia.valor).to eq(1000)
    end

  end

  describe 'atualizar_guia' do
    let!(:categoria_debito) { FactoryBot.create(:categoria_debito, aplicar_correcao: true, aplicar_juros: true, aplicar_multa: true) }
    let!(:debito) { FactoryBot.create(:debito, categoria_debito: categoria_debito) }
    let!(:fundesp) { FactoryBot.create(:item_arrecadacao, :fundesp) }
    let!(:juros_selic) { FactoryBot.create(:item_arrecadacao, :juros) }
    let!(:multa) { FactoryBot.create(:item_arrecadacao, :multa) }
    let!(:parcela) { FactoryBot.create(:parcela, debito: debito, valor_ref: 1000.0,
                                        valor: 1000.0, data_atualizacao: Date.new(2024, 1, 1),
                                        data_vencimento: Date.new(2024, 1, 1) ) }
    let!(:guia) { FactoryBot.create(:guia, parcela: parcela, valor: 1000.0) }
    let!(:guia_item) { FactoryBot.create(:guia_item_arrecadacao, guia: guia, item_arrecadacao: fundesp, valor: 1000.0) }

    before do
      allow(Indices::Selic).to receive(:indice_periodo).and_return(1.0)
      allow(Indices::Ipca).to receive(:indice_periodo).and_return(1.0)
      Timecop.freeze(Date.new(2024, 7, 1))
      parcela.atualizar_guia
    end

    it 'atualiza valor da guia' do
      expect(guia.reload.valor).to eq(1212)
    end

    it 'cria item de arrecadação juros/selic' do
      expect(guia.guia_itens_arrecadacao.map(&:item_arrecadacao_id)).to include(juros_selic.id)
    end

    it 'cria item de arrecadação multa' do
      expect(guia.guia_itens_arrecadacao.map(&:item_arrecadacao_id)).to include(multa.id)
    end


  end

end