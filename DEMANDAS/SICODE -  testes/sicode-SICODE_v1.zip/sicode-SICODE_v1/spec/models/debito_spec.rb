require 'rails_helper'

RSpec.describe Debito, type: :model do
  describe 'associations' do
    it { should have_many(:debito_itens).dependent(:destroy) }
  end

  describe 'validations' do
    it { should validate_presence_of(:nome) }
    it { should validate_presence_of(:valor_ref) }
    it { should validate_presence_of(:data_ref) }

    context 'validates cpf' do
      it 'is valid' do
        debito = FactoryBot.build(:debito, cpf: Faker::CPF.numeric)
        expect(debito).to be_valid
      end

      it 'is invalid' do
        debito = FactoryBot.build(:debito, cpf: '123456')
        expect(debito).to_not be_valid
      end
    end
  end

  describe 'enums' do
    it { should define_enum_for(:categoria).with_values(diferenca_arrecadacao: 'diferenca_arrecadacao', teto: 'teto').backed_by_column_of_type(:string) }
    it { should define_enum_for(:situacao).with_values(aguardando_pagamento: 'aguardando_pagamento', pago: 'pago', vencido: 'vencido', protesto: 'protesto', protesto_pago: 'protesto_pago', cancelado: 'cancelado', divida_ativa: 'divida_ativa').backed_by_column_of_type(:string) }
  end

  describe 'accepts_nested_attributes_for' do
    it { should accept_nested_attributes_for(:debito_itens).allow_destroy(true) }
  end

  describe 'public methods' do
    let!(:debito) { FactoryBot.create(:debito) }

    context 'registrar' do
      let!(:debito_item) { FactoryBot.create(:debito_item, debito: debito, valor_ref: 1000.0, data_ref: Date.new(2024, 1, 1)) }
      before do
        allow(SecureRandom).to receive(:hex).and_return('123456')
        allow(IndicadorFinanceiro).to receive(:indice_selic_periodo).and_return(1.0)
        allow(Date).to receive(:current).and_return(Date.new(2024, 4, 1))
        debito.registrar
      end

      it 'calcula valor atualizado' do
        expect(debito.valor_atualizado).to eq(1212.0)
      end

      it 'atualiza data de atualizacao' do
        expect(debito.data_atualizacao).to eq(Date.current)
      end

      it 'atualiza situacao' do
        expect(debito.situacao).to eq('aguardando_pagamento')
      end

      it 'atualiza data de vencimento' do
        expect(debito.data_vencimento).to eq(Date.current + 30.days)
      end
    end

    context 'atualizar' do
      let!(:debito_item) { FactoryBot.create(:debito_item, debito: debito, valor_ref: 1000.0, data_ref: Date.new(2024, 1, 1)) }
      before do
        allow(Indices::Selic).to receive(:indice_periodo).and_return(1.0)
        allow(Date).to receive(:current).and_return(Date.new(2024, 4, 1))
        debito.atualizar
      end

      it 'calcula valor atualizado' do
        expect(debito.valor_atualizado).to eq(1212.0)
      end

      it 'atualiza data de atualizacao' do
        expect(debito.data_atualizacao).to eq(Date.current)
      end
    end

    context 'parcelar' do
     context  'divide o valor total em n parcelas iguais' do
        let!(:debito_p1) { FactoryBot.create(:debito) }
        let!(:debito_item) { FactoryBot.create(:debito_item, debito: debito_p1, valor_ref: 1000.0, data_ref: Date.new(2024, 4, 1), valor_atualizado: 1000.0) }
        before do
          allow(Date).to receive(:current).and_return(Date.new(2024, 4, 1))
          debito_p1.parcelar(data_primeira_parcela: Date.new(2024, 4, 1), numero_parcelas: 3)
        end

        it 'gera n parcelas' do
          expect(debito_p1.parcelas.count).to eq(3)
        end

        it 'valor da parcela' do
          expect(debito_p1.parcelas.first.valor.to_f).to eq(333.33)
        end

        it 'data de vencimento' do
          expect(debito_p1.parcelas.first.data_vencimento).to eq(Date.new(2024, 4, 1))
        end
     end

      context 'caso informado o valor da primeira parcela, o restante é dividido em n-1 parcelas' do
        let!(:debito_p2) { FactoryBot.create(:debito) }
        let!(:debito_item) { FactoryBot.create(:debito_item, debito: debito_p2, valor_ref: 1000.0, data_ref: Date.new(2024, 4, 1), valor_atualizado: 1000.0) }
        before do
          allow(Date).to receive(:current).and_return(Date.new(2024, 4, 1))
          debito_p2.parcelar(data_primeira_parcela: Date.new(2024, 4, 1), numero_parcelas: 3, valor_primeira_parcela: 300.0)
        end

        it 'gera n parcelas' do
          expect(debito_p2.parcelas.count).to eq(3)
        end

        it 'valor da parcela' do
          expect(debito_p2.parcelas.first.valor.to_f).to eq(300.0)
        end

        it 'data de vencimento' do
          expect(debito_p2.parcelas.first.data_vencimento).to eq(Date.new(2024, 4, 1))
        end
      end
    end
  end
end