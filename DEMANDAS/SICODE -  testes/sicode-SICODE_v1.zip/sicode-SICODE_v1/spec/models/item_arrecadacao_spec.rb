require 'rails_helper'

RSpec.describe ItemArrecadacao, type: :model do
  describe 'validations' do
    it 'validates presence of required attributes' do
      should validate_presence_of(:nome)
      should validate_presence_of(:codigo_arrecadacao)
      should validate_presence_of(:data_inicio_vigencia)
      should validate_presence_of(:data_fim_vigencia)
      # Add more attribute validations as needed
    end

    # Add more validation tests as needed

  end

  describe 'associations' do
    it 'should belong to a parent model' do
      #should belong_to(:parent_model)
    end

    # Add more association tests as needed

  end

  describe 'scopes' do
    it 'ativos' do
      expect(ItemArrecadacao.ativos).to eq(ItemArrecadacao.where(ativo: true))
    end

    it 'vigentes' do
      expect(ItemArrecadacao.vigentes).to eq(ItemArrecadacao.ativos.where('data_inicio_vigencia <= ? AND data_fim_vigencia >= ?', Date.current, Date.current))
    end

    it 'selecionavies' do
      expect(ItemArrecadacao.selecionavies).to eq(ItemArrecadacao.ativos.vigentes.where(tipo_taxa: [1,6]).order(:nome))
    end
  end

  describe 'methods' do
    # Add tests for custom methods as needed

    it '.tipo_taxa_attributes_for_select' do
      expect(ItemArrecadacao.tipo_taxa_attributes_for_select).to eq([["Emolumento", "emolumento"], ["Taxa judiciária", "taxa"],
          ['Juros','juros'],["Diversos", "diversos"], ["Fundos", "fundos"], ["Diferença Débito", "diferenca_debito"]])
    end

  end

  # describe enuns
  describe 'enums' do
    it 'tipo_taxa' do
      should define_enum_for(:tipo_taxa)
        .with_values(emolumento: 1, taxa: 2, juros: 3, diversos: 4, fundos: 5, diferenca_debito: 6)
    end
  end
end