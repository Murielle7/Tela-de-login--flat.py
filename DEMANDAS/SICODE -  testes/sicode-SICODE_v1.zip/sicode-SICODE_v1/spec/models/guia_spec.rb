require 'rails_helper'

RSpec.describe Guia, type: :model do
  let!(:item_fundesp) { FactoryBot.create(:item_arrecadacao, :fundesp) }
  let!(:item_multa) { FactoryBot.create(:item_arrecadacao, :multa) }
  let!(:item_juros) { FactoryBot.create(:item_arrecadacao, :juros) }

  describe 'associations' do
    it { should belong_to(:parcela) }
    it { should have_one(:debito).through(:parcela)}
  end

  describe 'validations' do
    it { should validate_presence_of(:valor) }
    it { should validate_presence_of(:data_vencimento) }
  end

  describe 'enums' do
    it { should define_enum_for(:situacao).with_values([:aguardando_pagamento, :paga, :cancelada , :divida_ativa]) }

    it { should define_enum_for(:tipo).with_values([:unica, :parcela]) }
  end

  it 'gera o numero da guia com 8 digitos sendo os ultimos 2 a serie' do
    debito = FactoryBot.create(:debito)
    parcela = FactoryBot.create(:parcela, debito: debito)
    guia = FactoryBot.create(:guia, parcela: parcela)
    expect(guia.numero).to match(/\d{8}20/)
  end

  describe 'valor' do
    it 'valor é igual a soma dos itens de arrecadação' do
      debito = FactoryBot.create(:debito)
      parcela = FactoryBot.create(:parcela, debito: debito)
      guia = FactoryBot.create(:guia, parcela: parcela)

      guia_item_arrecadacao = FactoryBot.create(:guia_item_arrecadacao, guia: guia, item_arrecadacao: item_fundesp, valor: 1000.0)
      expect(guia.valor_total).to eq(1000.0)
      guia.save
      expect(guia.valor).to eq(1000.0)
    end
  end

  describe 'valor atualizado' do
    let(:debito) { FactoryBot.create(:debito, data_ref: (Date.current  - 6.months)) }
    let(:parcela) { FactoryBot.create(:parcela, debito: debito, valor: 1000.0, data_ref: debito.data_ref) }
    let!(:guia) { FactoryBot.create(:guia, parcela: parcela, valor: 1000) }
    let!(:guia_item_arrecadacao) { FactoryBot.create(:guia_item_arrecadacao, guia: guia, item_arrecadacao: item_fundesp, valor: 1000.0) }

    before do
      guia.atualizar_valor
    end

    it 'valor atualizado é igual ao valor atualizado da parcela' do
      expect(guia.valor).to eq(1000.0)
    end

    it 'exclui item de arrecadação e cria um novo' do
      expect(guia.guia_itens_arrecadacao.first).to_not eq(guia_item_arrecadacao)
    end

    it 'atualiza numero da guia' do
      expect(parcela.guia.numero).to_not eq(guia.numero)
    end
  end

end