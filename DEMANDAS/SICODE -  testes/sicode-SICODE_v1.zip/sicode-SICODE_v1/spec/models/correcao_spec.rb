# correcao_spec.rb

require 'rails_helper'

RSpec.describe Correcao, type: :model do
  context 'calcular' do
    before {allow_any_instance_of(Correcao).to receive(:indice_ipca).and_return(1.0)}

    it 'calcula correcao' do
      correcao = Correcao.new(options: {valor_original: 1000.0, indice: 1.0, data_ref: Date.new(2017, 1, 1), data_final: Date.new(2017, 1, 31)})
      expect(correcao.valor.to_f).to eq(10.0)
    end
  end

  context '.indice_ipca' do
    before do
      FactoryBot.create(:indicador_financeiro, tipo: 'ipca', valor: 1.0, inicio: Date.new(2017, 1, 1), final: Date.new(2017, 1, 31),
                        acumulado: 3512.04)
      FactoryBot.create(:indicador_financeiro, tipo: 'ipca', valor: 2.0, inicio: Date.new(2017, 2, 1), final: Date.new(2017, 2, 28),
                        acumulado: 5348.49)
      FactoryBot.create(:indicador_financeiro, tipo: 'ipca', valor: 3.0, inicio: Date.new(2017, 3, 1), final: Date.new(2017, 3, 31),
                        acumulado: 6348.49)
    end

    # Número-índice de março de 2020: 5.348,49
    # Número-índice de agosto de 2012: 3.512,04
    # Fator de correção: 5.348,49 / 3.512,04 = 1,5229
    # Valor corrigido: 1.000 x 1,5229 = R$ 1.522,90.
    it 'ipca_periodo' do
      c = Correcao.new(options: {data_ref: Date.new(2016, 12, 1), data_final: Date.new(2017, 3, 30)})
      expect(c.indice).to eq(1.5229)
    end

    it 'correcao_ipca_periodo' do
      c = Correcao.new(options: {valor_original: 1000.0, data_ref: Date.new(2016, 12, 1), data_final: Date.new(2017, 3, 30)})
      expect(c.valor.to_f).to eq(1522.9)
    end
  end
end