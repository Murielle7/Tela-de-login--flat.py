require 'rails_helper'

RSpec.describe Multa, type: :model do
  context 'calcular' do
    let!(:multa) { Multa.new(options: {valor_original: 1000.0,  data_ref: Date.new(2017, 1, 21), data_final: Date.new(2017, 2, 11)}) }

    before do
      multa.calcular
    end

    # data_final - data_ref = 21
    it 'dias' do
      expect(multa.dias).to eq(21)
    end

    # 0.0033 * 21 = 0.0693
    it 'calcula multa' do
      expect(multa.valor).to eq(69.3)
    end
  end
end
