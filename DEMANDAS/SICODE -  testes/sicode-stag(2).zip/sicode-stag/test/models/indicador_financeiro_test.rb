require "test_helper"

class IndicadorFinanceiroTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
