require 'test_helper'

class ApplicationDecoratorTest < Draper::TestCase
end
