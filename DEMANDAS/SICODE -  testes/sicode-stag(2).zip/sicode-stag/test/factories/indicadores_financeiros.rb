FactoryBot.define do
  sequence(:email_factory) { |n| "person#{n}@example.com" }
  sequence(:nome_factory) { |n| "person#{n}" }

  factory :indicador_financeiro do
    nome {generate(:nome_factory) }
    tipo { :selic}
    valor { 1.0 }
    inicio { Date.new(2017, 1, 1) }
    final { Date.new(2017, 1, 31) }
    acumulado { 0 }

    trait :ipca do
      tipo { :ipca }
      acumulado { 1000 }
    end
  end
end
