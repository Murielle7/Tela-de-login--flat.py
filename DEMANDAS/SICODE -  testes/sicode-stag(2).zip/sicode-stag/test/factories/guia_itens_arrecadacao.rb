FactoryBot.define do
  factory :guia_item_arrecadacao do
    guia { nil }
    item_arrecadacao { nil }
    valor { "9.99" }
    obs { "MyString" }
  end
end
