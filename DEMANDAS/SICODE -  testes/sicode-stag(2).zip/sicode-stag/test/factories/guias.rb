FactoryBot.define do
  factory :guia do
    parcela { nil }
    numero { "MyString" }
    data_emissao { "2024-04-16" }
    data_vencimento { "2024-04-16" }
    data_pagamento { "2024-04-16" }
    valor { "9.99" }
    valor_pago { "9.99" }
    situacao { 1 }
    tipo { 1 }
    lancado_spg { false }
    ativa { true }
    obs { "MyText" }
    cpf { "MyString" }
    cnpj { "MyString" }
    identificacao_sacado { "MyString" }
  end
end
