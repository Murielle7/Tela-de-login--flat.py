FactoryBot.define do
  factory :parcela do
    debito { nil }
    numero { 1 }
    valor_ref { "9.99" }
    valor { "9.99" }
    data_vencimento { "2024-04-12" }
    data_pagamento { "2024-04-12" }
    situacao { "MyString" }
  end
end
