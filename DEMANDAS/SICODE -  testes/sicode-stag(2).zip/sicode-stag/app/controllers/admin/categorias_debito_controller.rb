module Admin
  class CategoriasDebitoController < Admin::ApplicationController
    def index
      @categorias_debito = CategoriaDebito.search(search_params)
      @categorias_debito = CategoriaDebitoDecorator.decorate_collection(@categorias_debito)

      respond_to do |format|
        format.html
        format.turbo_stream do
          render turbo_stream: turbo_stream.replace('categorias_debito', partial: 'admin/categorias_debito/categoria_debito',
                                                                         locals: { categorias_debito: @categorias_debito })
        end
      end
    end

    def show
      @categoria_debito = CategoriaDebito.find(params[:id])
      @categoria_debito = CategoriaDebitoDecorator.decorate(@categoria_debito)
    end

    def new
      @categoria_debito = CategoriaDebito.new
      authorize @categoria_debito
    end

    def edit
      @categoria_debito = CategoriaDebito.find(params[:id])
      authorize @categoria_debito
    end

    def create
      @categoria_debito = CategoriaDebito.new(categoria_debito_params)
      authorize @categoria_debito

      if @categoria_debito.save
        redirect_to admin_categorias_debito_path, notice: 'Categoria de débito criada com sucesso'
      else
        flash.now[:alert] = 'Não foi possível criar a categoria de débito'
        render :new
      end
    end

    def update
      @categoria_debito = CategoriaDebito.find(params[:id])
      authorize @categoria_debito

      if @categoria_debito.update(categoria_debito_params)
        redirect_to admin_categorias_debito_path, notice: 'Categoria de débito atualizada com sucesso'
      else
        flash.now[:alert] = 'Não foi possível atualizar a categoria de débito'
        render :edit
      end
    end

    def destroy
      @categoria_debito = CategoriaDebito.find(params[:id])
      authorize @categoria_debito
      @categoria_debito.destroy

      respond_to do |format|
        format.html { redirect_to admin_categorias_debito_path, notice: 'Categoria de débito removida com sucesso' }
        format.turbo_stream { render turbo_stream: turbo_stream.remove(@categoria_debito) }
      end
    end

    private

    def categoria_debito_params
      params.require(:categoria_debito).permit(:nome, :ativo, :aplicar_correcao, :aplicar_juros, :aplicar_multa)
    end

    def search_params
      params.permit(:nome, :ativo, :sort_by, :page)
    end
  end
end
