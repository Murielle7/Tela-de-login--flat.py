module Admin
  class ParcelasController < Admin::ApplicationController
    before_action :set_debito

    def new
      @parcela = @debito.parcelas.build
    end

    def show
      @parcela = @debito.parcelas.find(params[:id])
    end

    def create
      @parcela = @debito.parcelar(data_primeira_parcela: parcela_params[:data_primeira_parcela],
                                  numero_parcelas: parcela_params[:numero_parcelas], valor_primeira_parcela: parcela_params[:valor_primeira_parcela])
      respond_to do |format|
        format.js
        format.html do
          if @parcela
            redirect_to admin_debito_path(@debito), notice: 'Parcela criada com sucesso'
          else
            flash.now[:alert] = 'Não foi possível criar a parcela'
            redirect_to admin_debito_path(@debito)
          end
        end
        format.turbo_stream do
          render turbo_stream: turbo_stream.replace('parcelas', partial: 'admin/debitos/parcela',
                                                                locals: { debito: @debito })
        end
      end
    end

    def atualizar
      @parcela = @debito.parcelas.find(params[:id])
      respond_to do |format|
        format.js
        format.html do
          if @parcela.atualizar
            redirect_to admin_debito_path(@debito), notice: 'Parcela atualizada com sucesso'
          else
            flash.now[:alert] = 'Não foi possível atualizar a parcela'
            redirect_to admin_debito_path(@debito)
          end
        end
        format.turbo_stream do
          render turbo_stream: turbo_stream.replace('parcelas', partial: 'admin/debitos/parcela',
                                                                locals: { debito: @debito })
        end
      end
    end

    def confirmar
      if @debito.confirmar_parcelamento
        redirect_to admin_debito_path(@debito), notice: 'Parcelamento confirmado com sucesso'
      else
        redirect_to admin_debito_path(@debito), alert: 'Não foi possível confirmar o parcelamento'
      end
    end

    def negar
      if @debito.negar_parcelamento
        redirect_to admin_debito_path(@debito), notice: 'Parcelamento negado com sucesso'
      else
        redirect_to admin_debito_path(@debito), alert: 'Não foi possível negar o parcelamento'
      end
    end

    private

    def set_debito
      @debito = Debito.find(params[:debito_id])
    end

    def parcela_params
      params.permit(:data_primeira_parcela, :numero_parcelas, :valor_primeira_parcela)
    end
  end
end
