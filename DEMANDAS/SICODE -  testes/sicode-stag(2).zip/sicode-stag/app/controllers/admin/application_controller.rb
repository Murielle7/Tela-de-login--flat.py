module Admin
  class ApplicationController < ApplicationController
    include Pundit::Authorization
    before_action :authenticate_user!
    #before_action :check_admin

    rescue_from DeviseLdapAuthenticatable::LdapException do |exception|
      render :text => exception, :status => 500
    end

    rescue_from Net::LDAP::Error do |exception|
      render :text => exception, :status => 500
    end

    rescue_from Pundit::NotAuthorizedError, with: :user_not_authorized

    def after_sign_in_path_for(resource)
      admin_root_path
    end

    private

    def user_not_authorized(exception)
      policy_name = exception.policy.class.to_s.underscore

      flash[:error] = t "#{policy_name}.#{exception.query}", scope: "pundit", default: :default
      redirect_back(fallback_location: root_path)
    end
  end
end