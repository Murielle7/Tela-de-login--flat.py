module Admin
  class GuiasController < Admin::ApplicationController
    def index
      @guias = Guia.search(search_params)
      @guias = GuiaDecorator.decorate_collection(@guias)
    end

    def show
      @guia = Guia.find(params[:id])
      @guia = GuiaDecorator.new(@guia)
    end

    def registrar_saj
      @guia = Guia.find(params[:id])
      retorno = @guia.registrar_saj
      if retorno.status == :ok
        redirect_to admin_guias_path, notice: 'Guia registrada com sucesso'
      else
        redirect_to admin_guia_path(@guia), alert: "Erro ao registrar guia: #{retorno.message}"
      end
    end

    def atualizar_saj
      guias = Guia.ativas.aguardando_pagamento
      saj = ::GuiaService.new

      saj.consultar_pagamento(guias)
      if saj.status == :ok
        redirect_to admin_guias_path, notice: saj.message
      else
        redirect_to admin_guias_path, alert: "Erro ao atualizar informações de pagamento: #{saj.message}"
      end
    end

    private

    def search_params
      params.permit(:numero, :data_vencimento, :valor, :situacao, :tipo, :ativa, :cpf, :nome, :page, :per_page,
                    :sort_by)
    end
  end
end
