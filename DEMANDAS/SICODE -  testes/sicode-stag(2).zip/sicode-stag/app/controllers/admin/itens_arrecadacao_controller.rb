module Admin
  class ItensArrecadacaoController < Admin::ApplicationController
    skip_before_action :authenticate_user!, only: [:autocomplete]

    def index
      @itens_arrecadacao = ItemArrecadacao.search(params)
    end

    def show
      @item_arrecadacao = ItemArrecadacao.find(params[:id])
      @item_arrecadacao = ItemArrecadacaoDecorator.new(@item_arrecadacao)
    end

    def new
      @item_arrecadacao = ItemArrecadacao.new
    end

    def create
      @item_arrecadacao = ItemArrecadacao.new(item_arrecadacao_params)
      if @item_arrecadacao.save
        redirect_to admin_itens_arrecadacao_path, notice: 'Item de arrecadação criado com sucesso'
      else
        render :new
      end
    end

    def edit
      @item_arrecadacao = ItemArrecadacao.find(params[:id])
    end

    def update
      @item_arrecadacao = ItemArrecadacao.find(params[:id])
      if @item_arrecadacao.update(item_arrecadacao_params)
        redirect_to admin_itens_arrecadacao_path, notice: 'Item de arrecadação atualizado com sucesso'
      else
        render :edit
      end
    end

    def destroy
      @item_arrecadacao = ItemArrecadacao.find(params[:id])
      @item_arrecadacao.destroy
      redirect_to admin_itens_arrecadacao_path, notice: 'Item de arrecadação excluído com sucesso'
    end

    def autocomplete
      @itens_arrecadacao = ItemArrecadacao.all
      @itens_arrecadacao = @itens_arrecadacao.where("nome ilike ?", "%#{params[:q]}%") if params[:q].present?

      render json: @itens_arrecadacao.map { |item| { id: item.id, text: item.nome } }
    end

    private

    def item_arrecadacao_params
      params.require(:item_arrecadacao).permit(:nome, :codigo, :valor)
    end
  end
end