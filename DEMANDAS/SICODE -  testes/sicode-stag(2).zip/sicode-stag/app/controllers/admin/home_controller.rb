module Admin
  class HomeController < Admin::ApplicationController
    def index
    end
  end
end