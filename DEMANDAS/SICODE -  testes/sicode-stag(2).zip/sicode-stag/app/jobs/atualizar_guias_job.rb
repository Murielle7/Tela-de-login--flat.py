class AtualizarGuiasJob < ApplicationJob
  queue_as :default

  def perform(*_args)
    guias = Guia.ativas.aguardando_pagamento
    saj = Services::GuiaService.new
    saj.consultar_pagamento(guias)
  end
end
