import { Controller } from "stimulus";

export default class extends Controller {
  static targets = [ "input", "hint" ]

  connect() {
    console.log("Categorias controller connected")
    log(this.inputTarget)
    this.eventlistener()
  }

  eventlistener() {
    console.log("Event listener")
    this.inputTarget.addEventListener("change", this.toggle.bind(this))
  }

  toggle() {
    console.log("Toggling", this.categoriaTarget)
    this.hintTarget.classList.toggle("hidden")
  }
}