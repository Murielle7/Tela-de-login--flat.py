import { Application } from "@hotwired/stimulus"
import RailsNestedForm from '@stimulus-components/rails-nested-form'
//import Search from "./search"
import HwComboboxController from "@josefarias/hotwire_combobox"


const application = Application.start()
application.register('nested-form', RailsNestedForm)
application.register("hw-combobox", HwComboboxController)

application.debug = true
window.Stimulus   = application

export { application }
