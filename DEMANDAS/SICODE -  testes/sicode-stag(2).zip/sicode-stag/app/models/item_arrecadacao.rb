class ItemArrecadacao < ApplicationRecord
  belongs_to :categoria_debito, optional: true
  has_many :debito_items

  validates :nome, :codigo_arrecadacao, :data_inicio_vigencia, :data_fim_vigencia, presence: true

  enum tipo_taxa: {emolumento: 1, taxa: 2, juros: 3, diversos: 4, fundos: 5, diferenca_debito: 6}

  scope :ativos, -> { where(ativo: true) }
  scope :vigentes, -> { ativos.where('data_inicio_vigencia <= ? AND data_fim_vigencia >= ?', Date.current, Date.current) }
  scope :selecionaveis, -> { ativos.vigentes.where(tipo_taxa: [4,6]).order(:nome) }

  delegate :nome, to: :categoria_debito, prefix: true, allow_nil: true

  def info
    "#{codigo_arrecadacao} - #{nome}"
  end

  def self.item_custas
     ItemArrecadacao.vigentes.ativos.find_by(codigo_arrecadacao: '5045')
  end

  def self.item_juros
    ItemArrecadacao.vigentes.ativos.find_by(codigo_arrecadacao: '5263')
  end

  def self.item_multa
    ItemArrecadacao.vigentes.ativos.find_by(codigo_arrecadacao: '5244')
  end

  def self.search(params = {})
    resultado = self.selecionaveis.includes(:categoria_debito)
    resultado = resultado.where('nome ILIKE ?', "%#{params[:nome]}%") if params[:nome].present?
    resultado = resultado.where('codigo_arrecadacao = ?', params[:codigo_arrecadacao]) if params[:codigo_arrecadacao].present?
    resultado = resultado.where('categoria_debito_id = ?', params[:categoria_debito_id]) if params[:categoria_debito_id].present?
    resultado = resultado.where('tipo_taxa = ?', params[:tipo_taxa]) if params[:tipo_taxa].present?
    resultado = resultado.where('ativo = ?', params[:ativo]) if params[:ativo].present?
    resultado = resultado.where('data_inicio_vigencia >= ?', params[:data_inicio_vigencia]) if params[:data_inicio_vigencia].present?
    resultado = resultado.where('data_fim_vigencia <= ?', params[:data_fim_vigencia]) if params[:data_fim_vigencia].present?
    resultado.order(params[:sort_by] || :nome).page(params[:page] || 1)
  end

  def self.tipo_taxa_attributes_for_select
    tipos_taxa.map do |tipo_taxa, _|
      [I18n.t("activerecord.attributes.item_arrecadacao.tipos_taxa.#{tipo_taxa}"), tipo_taxa]
    end
  end
end
