class GuiaItemArrecadacao < ApplicationRecord
  belongs_to :guia, dependent: :destroy
  belongs_to :item_arrecadacao

  validates :valor, presence: true

end
