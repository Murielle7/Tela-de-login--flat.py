class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :ldap_authenticatable, :registerable,
         :recoverable, :rememberable # , :validatable

  validates :username, presence: true, uniqueness: true
  # validates :nome, presence: true, on: :create

  enum role: { user: 0, admin: 1 }

  def ldap_before_save
    self.email = Devise::LDAP::Adapter.get_ldap_param(username, 'mail').first
    return unless email.blank?

    self.email = nil
  end
end
