class DebitoItem < ApplicationRecord
  belongs_to :debito
  belongs_to :item_arrecadacao

  validates :valor_ref, :data_ref, presence: true
  validate :categoria_debito_vinculo
  before_save :atualizar_valores, unless: -> { data_atualizacao == Date.current}


  def atualizar_valores
    calcular_correcao if aplicar_correcao?
    calcular_juros  if aplicar_juros?
    calcular_multa  if aplicar_multa?
    valor = (valor_ref + correcao + juros + multa )
    update(data_atualizacao: Date.current, valor_atualizado: valor )
  end

  private

  def calcular_correcao
    valor = valor_ref
    c = Correcao.new(options: {valor: valor, data_ref: data_ref})
    c.calcular
    self.correcao = c.valor
  rescue
    0
  end

  def calcular_juros
    valor = valor_ref + correcao
    j = Juro.new(options: {valor_original: valor, data_ref: data_ref})
    j.calcular
    self.juros = j.valor
  end

  def calcular_multa
    valor = valor_ref + correcao + juros
    m = Multa.new(options: {valor_original: valor, data_ref: data_ref})
    m.calcular
    self.multa = m.valor
  end

  def aplicar_correcao?
    debito.categoria_debito.aplicar_correcao?
  end

  def aplicar_juros?
    debito.categoria_debito.aplicar_juros?
  end

  def aplicar_multa?
    debito.categoria_debito.aplicar_multa?
  end

  private

  def categoria_debito_vinculo
    return if debito.categoria_debito_id == item_arrecadacao.categoria_debito_id
    errors.add(:item_arrecadacao, 'não pertence a categoria de débito')
  end
end
