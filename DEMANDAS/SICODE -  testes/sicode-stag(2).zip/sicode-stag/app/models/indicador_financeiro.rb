class IndicadorFinanceiro < ApplicationRecord
  validates :valor, :inicio, :final, presence: true
  validate :referencia_overlap, on: [:create, :update]

  enum tipo: { selic: 'selic', ipca: 'ipca' }

  private

  # Valida se a referencia do indicador financeiro não está sobrepondo
  # com outro já cadastrado
  def referencia_overlap
    return if tipo.blank? || inicio.blank? || final.blank?

    if IndicadorFinanceiro.where(tipo: tipo).where(['(:inicio between inicio and final) or (:final between inicio and final)', {inicio: inicio, final: final}]).where.not(id: id).exists?
      errors.add(:base, 'Referência já cadastrada')
    end
  end

end
