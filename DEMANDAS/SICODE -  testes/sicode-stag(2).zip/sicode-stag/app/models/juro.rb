class Juro
  attr_reader :valor, :valor_original ,:dias, :indice

  def initialize(options: {})
    @valor_original = options.fetch(:valor_original, 0.0)
    @valor = options.fetch(:valor, 0.0)
    @data_ref = options.fetch(:data_ref, Date.today).blank? ? Date.today : options.fetch(:data_ref, Date.today)
    @data_final = options.fetch(:data_final, Date.today).blank? ? Date.today : options.fetch(:data_final, Date.today)
    @dias = options.fetch(:dias, calcula_dias)
    @indice = options.fetch(:indice, indice_selic)
    calcular
  end

  def calcular
    return if dias.zero? || indice.zero?
    return if @data_final.strftime('%Y%m') == @data_ref.strftime('%Y%m')
    return if indice_selic.zero? || indice_selic.negative?

    @valor = (valor_original * (indice_selic / 100)).round(2)
  end

  def indice_selic
    Indices::Selic.indice_periodo(@data_ref, @data_final)
  end

  def calcula_dias
    (@data_final - @data_ref).to_i
  rescue
    0
  end
end