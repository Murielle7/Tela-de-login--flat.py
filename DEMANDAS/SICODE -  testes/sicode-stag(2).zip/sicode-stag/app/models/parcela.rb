class Parcela < ApplicationRecord
  belongs_to :debito
  has_many :guias
  has_one :guia, -> { where(ativa: true) }

  validates :valor_ref, :data_vencimento, presence: true
  validates :numero, uniqueness: { scope: :debito_id }
  validate :guia_ativa, on: :destroy

  scope :ativas, -> { where(ativa: :true) }
  scope :vencidas, -> { where('data_vencimento < ?', Date.current) }

  enum situacao: { aguardando_confirmacao: 'aguardando_confirmacao', aguardando_pagamento: 'aguardando_pagamento',
                   paga: 'paga', protesto: 'protesto', protesto_pago: 'protesto_pago', cancelada: 'cancelada', divida_ativa: 'divida_ativa' }

  def gerar_guia
    return atualizar_guia if guia.present? && data_vencimento < Date.current
    return gerar_guia_atraso if guia.blank? && data_vencimento < Date.current

    obs_custas = debito.parcelas.count > 1 ? "Parcela #{numero} de #{debito.parcelas.count}" : 'Parcela única'

    guia = guias.find_or_create_by(ativa: true, valor:, data_vencimento:,
                                   tipo: (debito.parcelas.count > 1 ? 'parcela' : 'unica'))
    item = item_base
    guia.guia_itens_arrecadacao.create(item_arrecadacao: item_base, valor:, obs: obs_custas)
    guia.save
    guia.registrar_saj
    update(situacao: :aguardando_pagamento)
  end

  def gerar_guia_atraso
    item = item_base
    item_juros = ItemArrecadacao.item_juros
    item_multa = ItemArrecadacao.item_multa

    obs_custas = debito.parcelas.count > 1 ? "Parcela #{numero} de #{debito.parcelas.count}" : 'Parcela única'
    vencimento_atualizado = data_vencimento > Date.current ? data_vencimento : Date.current + 1.days

    guia = guias.find_or_create_by(ativa: true, valor:, data_vencimento: vencimento_atualizado,
                                   tipo: (debito.parcelas.count > 1 ? 'parcela' : 'unica'))
    juros = calcular_juros
    correcao = calcular_correcao
    valor_atualizado = valor + juros + correcao
    multa = calcular_multa(valor: valor_atualizado)

    build_guia_itens(guia:, custas: { valor:, obs: obs_custas },
                     juros: { valor: juros },
                     multa: { valor: multa },
                     correcao: { valor: correcao })

    guia.save
    guia.registrar_saj
    update(situacao: :aguardando_pagamento)
  end

  def atualizar_guia
    guia_original = guia
    vencimento_atualizado = data_vencimento > Date.current ? data_vencimento : Date.current + 1.days
    juros = calcular_juros
    correcao = calcular_correcao
    valor_atualizado = guia_original.valor + juros + correcao
    multa = calcular_multa(valor: valor_atualizado)
    guia_original.update(ativa: false)
    guia = guias.find_or_create_by(ativa: true, valor: valor_atualizado, data_vencimento: vencimento_atualizado,
                                   tipo: (debito.parcelas.count > 1 ? 'parcela' : 'unica'))
    build_guia_itens(guia:, custas: { valor: guia_original.valor, obs: guia_original.obs },
                     juros: { valor: juros },
                     multa: { valor: multa },
                     correcao: { valor: correcao })
    guia.registrar_saj
    guia.save
  end

  def build_guia_itens(guia:, custas:, juros:, multa:, correcao:, guia_original: nil)
    dt_vencimento = guia_original.present? ? guia_original.data_vencimento : data_vencimento

    item_custas = item_base
    item_juros = ItemArrecadacao.item_juros
    item_multa = ItemArrecadacao.item_multa
    item_correcao = item_custas

    update(juros: juros[:valor], multa: multa[:valor], correcao: correcao[:valor])

    guia.guia_itens_arrecadacao.create(item_arrecadacao: item_custas, valor: custas[:valor],
                                       obs: custas.fetch(:obs, ''))
    if juros[:valor] > 0
      guia.guia_itens_arrecadacao.create(item_arrecadacao: item_juros, valor: juros[:valor],
                                         obs: "SELIC de #{dt_vencimento.strftime('%d/%m/%Y')} à #{Date.current.strftime('%d/%m/%Y')}")
    end

    if multa[:valor] > 0
      guia.guia_itens_arrecadacao.create(item_arrecadacao: item_multa, valor: multa[:valor],
                                         obs: "Multa de #{dt_vencimento.strftime('%d/%m/%Y')} à #{Date.current.strftime('%d/%m/%Y')}")
    end

    return unless correcao[:valor] > 0

    guia.guia_itens_arrecadacao.create(item_arrecadacao: item_correcao, valor: correcao[:valor],
                                       obs: "Correção de #{dt_vencimento.strftime('%d/%m/%Y')} à #{Date.current.strftime('%d/%m/%Y')}")
  end

  def valor_atualizado
    [valor_ref.to_d, juros.to_d, multa.to_d, correcao.to_d].sum
  end

  def item_base
    return ItemArrecadacao.item_custas if debito.debito_itens.count > 1

    debito.debito_itens.first.item_arrecadacao
  rescue StandardError
    ItemArrecadacao.item_custas
  end

  def calcular_correcao
    return 0 unless debito.categoria_debito.aplicar_correcao?

    valor = valor_ref
    c = Correcao.new(options: { valor_original: valor, data_ref: data_vencimento })
    c.calcular
    c.valor
  rescue StandardError
    0
  end

  def calcular_juros(valor: valor_ref)
    return 0 unless debito.categoria_debito.aplicar_juros?

    j = Juro.new(options: { valor_original: valor, data_ref: data_vencimento })
    j.calcular
    j.valor
  end

  def calcular_multa(valor: valor_ref)
    return 0 unless debito.categoria_debito.aplicar_multa?

    m = Multa.new(options: { valor_original: valor, data_ref: data_vencimento })
    m.calcular
    m.valor
  end

  def confirmar
    update(ativa: true, situacao: :aguardando_pagamento)
  end

  private

  def guia_ativa
    return if guia.blank?

    errors.add(:guia, 'Existe uma guia vinculada a esta parcela')
  end
end
