# Correção IPCA
class Correcao
  attr_reader :valor, :indice, :data_ref, :data_final

  def initialize(options: {})
    @valor_ref = options.fetch(:valor, 0.0)
    @valor = @valor_ref
    @data_ref = options.fetch(:data_ref, Date.today).blank? ? Date.today : options.fetch(:data_ref, Date.today)
    @data_final = options.fetch(:data_final, Date.today).blank? ? Date.today : options.fetch(:data_final, Date.today)
    parse_dates
    @indice = indice_ipca
    calcular
  end

  def calcular
    return if @indice.zero?
    return if @data_final.strftime('%Y%m') == @data_ref.strftime('%Y%m')
    return if @indice.zero? || @indice.negative?

    @valor = (@valor_ref * @indice).round(2)
  end

  def indice_ipca
    Indices::Ipca.indice_periodo(@data_ref, @data_final)
  end

  def parse_dates
    @data_ref = Date.parse(@data_ref) if @data_ref.is_a? String
    @data_final = Date.parse(@data_final) if @data_final.is_a? String
  end

end
