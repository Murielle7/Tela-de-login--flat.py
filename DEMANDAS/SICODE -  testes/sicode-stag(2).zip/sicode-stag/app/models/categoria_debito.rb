class CategoriaDebito < ApplicationRecord
  self.table_name = 'categoria_debitos'
  has_many :itens_arrecadacao

  def self.search(params={})
    resultados = self.all
    resultados = resultados.where("nome ILIKE ?", "%#{params[:nome]}%") if params[:nome].present?
    resultados = resultados.where(ativo: params[:ativo]) if params[:ativo].present?
    resultados = resultados.order(params[:sort_by] || :nome)
    resultados.page(params[:page] || 1)
  end
end
