module Indices
  module Selic

    def self.importar(ultimos: 0, data_inicial: nil, data_final: nil)
      # data_inicial = Date.new(2017, 1, 1)
      # data_final = Date.new(2023, 12, 1)

      selic_service = BancoCentral::SelicService.new
      if data_inicial.present? && data_final.present?
        selic_service.por_periodo(data_inicial, data_final)
      else
        ultimos = 1 if ultimos.to_i.zero?
        selic_service.ultimos(ultimos)
      end

      return unless selic_service.res.status == 200

      selic_service.parsed_response.each do |selic|
        data = selic['data'].to_date
        indicador = IndicadorFinanceiro.find_or_initialize_by(tipo: 'selic', nome: "SELIC #{data.strftime('%m/%Y')}",
                                              inicio: data,
                                              final: data.end_of_month,
                                              percentual: true, ativo: true)
        indicador.valor = selic['valor'].to_f
        indicador.save
      end
    end

    def self.periodo(inicio, final=Date.today)
      inicio = inicio.next_month.beginning_of_month
      final = (final - 1.month).end_of_month
      IndicadorFinanceiro.where(tipo: :selic, inicio: inicio..final, final: inicio..final).uniq
    end

    def self.indice_periodo(inicio, final=Date.today)
      selics = periodo(inicio, final)
      return 1 if selics.empty?

      i = selics.map(&:valor).sum + 1.0
      i
    end
  end
end