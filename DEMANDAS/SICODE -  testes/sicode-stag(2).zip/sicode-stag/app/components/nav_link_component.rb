# frozen_string_literal: true

class NavLinkComponent < ViewComponent::Base
  def initialize(url:, text:, icon:, current_controller:)
    @url = url
    @text = text
    @icon = icon
    @current_controller = current_controller
  end

  def link_klass
    klass = 'nav-link mininav-toggle'
    klass += ' active' if current_page?(controller: @current_controller)
    klass
  end
end
