# frozen_string_literal: true

class UserComponent < ViewComponent::Base
  def initialize(user:)
    @user = user
  end

  def render?
    @user
  end

  def nome
    @user&.nome
  end

  def username
    @user&.username
  end

  def email
    @user&.email
  end

  def role
    return '' if @user&.role.blank?
    I18n.t("activerecord.attributes.user.roles.#{@user&.role}")
  end

end
