# frozen_string_literal: true

class PaginateComponent < ViewComponent::Base
  def initialize(collection:, remote: false, options: {})
    @collection = collection
    @remote = remote
    @options = options
  end

end
