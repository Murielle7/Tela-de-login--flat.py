# frozen_string_literal: true

class ErrorMessagesComponent < ViewComponent::Base
  def initialize(resource:)
    @resource = resource
  end

  def render?
    return false unless @resource
    @resource.errors.any?
  end

end
