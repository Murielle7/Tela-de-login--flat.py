# frozen_string_literal: true

class SortBarComponent < ViewComponent::Base
  def initialize(path:, method: 'get', fields: nil)
    @path = path
    @method = method
    @fields = fields || default_fields
  end

  def default_fields
    [['Data de criação', 'created_at'], ['Data de atualização', 'updated_at']]
  end

end
