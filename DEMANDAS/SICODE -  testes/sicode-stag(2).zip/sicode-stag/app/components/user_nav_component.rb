# frozen_string_literal: true

class UserNavComponent < ViewComponent::Base
  def initialize(user: nil)
    @user = user
  end

  def render?
    @user.present?
  end

  def nome
    @user.nome
  end

  def role
    I18n.t("activerecord.attributes.user.roles.#{@user.role}")
  end
end
