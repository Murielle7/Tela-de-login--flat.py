# frozen_string_literal: true

class DeleteButtonComponent < ViewComponent::Base
  def initialize(url:, turbo: false, title: 'Remover', texto: nil)
    @url = url
    @turbo = turbo
    @title = title
    @texto = texto
  end

  def data
    data = { confirm: 'Você tem certeza?' }
    data
  end

  def icon_class
    return 'fas fa-trash'
  end

  def link_class
    return 'btn btn-danger'
  end

  def texto
    "<span class='vr'></span>".html_safe + @texto if @texto
  end

end
