# frozen_string_literal: true

class IncluirGuiaSajComponent < ViewComponent::Base
  def initialize(guia:)
    @guia = guia
  end

  def render?
    return false if @guia.situacao == 'paga'
    return false if @guia.lancado_spg?
    return false if @guia.numero.blank?
    return false if @guia.data_vencimento.blank?

    true
  end

  def url
    registrar_saj_admin_guia_path(@guia)
  end
end
