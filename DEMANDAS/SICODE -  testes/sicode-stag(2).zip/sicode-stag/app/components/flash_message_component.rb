# frozen_string_literal: true

class FlashMessageComponent < ViewComponent::Base
  with_collection_parameter :flash

  def initialize(flash:)
    super
    @flash = flash
  end

  def klass(f)
    return 'warning' if f[0] == 'alert'
    return 'success' if f[0] == 'notice'
    return 'danger' if f[0] == 'error'

    'info'
  end

  def message(f)
    f[1].html_safe
  rescue
    ''
  end

  def render?
    @flash.any?
  end

end
