class IndicadorFinanceiroDecorator < ApplicationDecorator

  # Define presentation-specific methods here. Helpers are accessed through
  # `helpers` (aka `h`). You can override attributes, for example:
  #
  #   def created_at
  #     helpers.content_tag :span, class: 'time' do
  #       object.created_at.strftime("%a %m/%d/%y")
  #     end
  #   end

  def valor
    return "#{object.valor} %" if object.percentual?
    helpers.number_to_currency(object.valor, unit: "R$", separator: ",", delimiter: ".")
  end

  def inicio
    object.inicio.strftime("%d/%m/%Y")
  end

  def final
    object.final.strftime("%d/%m/%Y")
  end

  def tipo
    return if object.tipo.blank?
    I18n.t("activerecord.attributes.indicador_financeiro.tipos.#{object.tipo}")
  end

end
