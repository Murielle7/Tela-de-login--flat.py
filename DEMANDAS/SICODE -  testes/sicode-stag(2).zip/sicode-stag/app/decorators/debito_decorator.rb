class DebitoDecorator < ApplicationDecorator
  delegate_all

  def valor_formatado
    helpers.number_to_currency(object.valor)
  end

  def valor_ref
    helpers.number_to_currency(object.valor_ref)
  end

  def valor_atualizado
    helpers.number_to_currency(object.valor_atualizado)
  end

  def data_atualizacao
    object.data_atualizacao.strftime('%d/%m/%Y') if object.data_atualizacao.present?
  end

  def data_ref
    object.data_ref.strftime('%d/%m/%Y') if object.data_ref.present?
  end

  def cpf_cnpj
    return cpf_formatado if object.cpf.present?
    return cnpj_formatado if object.cnpj.present?
  end

  def cpf_formatado
    object.cpf.present? ? object.cpf.gsub(/(\d{3})(\d{3})(\d{3})(\d{2})/, '\1.\2.\3-\4') : ''
  end

  def cnpj_formatado
    object.cnpj.present? ? object.cnpj.gsub(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '\1.\2.\3/\4-\5') : ''
  end

  def data_vencimento
    object.data_vencimento.strftime('%d/%m/%Y') if object.data_vencimento.present?
  end

  def situacao
    I18n.t("activerecord.attributes.debito.situacoes.#{object.situacao}")
  end

  def categoria
    object.categoria_debito.nome
  end

  def situacao_badge
    klass = case object.situacao
    when 'aguardando_pagamento'
      'bg-warning'
    when 'pago'
      'bg-success'
    when 'cancelado'
      'bg-danger'
    end
    "<span class='badge #{klass} rounded-pill'>#{situacao}</span>".html_safe
  end

  def confirmar_ou_negar_parcelamento
    return '' if object.situacao != 'aguardando_pagamento'
    return '' if object.parcelas.empty?
    #return '' if object.parcelas.any? { |parcela| parcela.situacao != 'aguardando_pagamento' }
    return '' if object.parcelas.any? { |parcela| parcela.guia.present? }

    link_confirmar_parcelas  = if object.parcelas.any? { |parcela| parcela.situacao == 'aguardando_confirmacao' }
            h.button_to('Confirmar Parcelas', h.confirmar_admin_debito_parcelas_path(object), class: 'btn btn-success', turbo: false, data: {
          turbo: false, confirm: 'Deseja realmente confirmar as parcelas?'
        })
    else
      h.content_tag(:span, '', class: '')
    end

    link_negar_parcelas = h.button_to('Negar Parcelas', h.negar_admin_debito_parcelas_path(object), class: 'btn btn-danger', form: {turbo: false, data: {
          turbo: false, confirm: 'Deseja realmente negar as parcelas?'
        } })

    h.content_tag(:div, class: 'btn-group') do
      link_confirmar_parcelas + link_negar_parcelas
    end.html_safe
  end
end