class ApplicationDecorator < Draper::Decorator
  delegate_all

  def self.collection_decorator_class
    PaginateDecorator
  end

  # Define presentation-specific methods here. Helpers are accessed through
  # `helpers` (aka `h`). You can override attributes, for example:
  #
  #   def created_at
  #     helpers.content_tag :span, class: 'time' do
  #       object.created_at.strftime("%a %m/%d/%y")
  #     end
  #   end

  def created_at
    object.created_at.strftime("%d/%m/%Y %H:%M:%S")
  end

  def updated_at
    object.updated_at.strftime("%d/%m/%Y %H:%M:%S")
  end

  def ativo
    object.ativo ? 'Sim' : 'Não'
  end

  def ativa
    object.ativa ? 'Sim' : 'Não'
  end

  def translated_enum(enum_name)
    I18n.t("activerecord.attributes.#{object.class.name.underscore}.#{enum_name}.#{object.send(enum_name)}")
  end

end
