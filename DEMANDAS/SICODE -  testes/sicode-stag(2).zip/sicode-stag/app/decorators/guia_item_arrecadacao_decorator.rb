class GuiaItemArrecadacaoDecorator < ApplicationDecorator
  def valor_formatado
    number_to_currency(object.valor)
  end

  def descricao
    "#{object.item_arrecadacao&.codigo_arrecadacao} - #{object.item_arrecadacao.nome}"
  end

  def valor
    h.number_to_currency(object.valor) if object.valor.present?
  end

  def link_spg
    
  end
end