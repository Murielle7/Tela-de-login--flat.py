class ParcelaDecorator < ApplicationDecorator
  delegate_all

  def valor
    h.number_to_currency(object.valor) if object.valor.present?
  end

  def data_vencimento
    object.data_vencimento.strftime('%d/%m/%Y') if object.data_vencimento.present?
  end

  def juros
    h.number_to_currency(object.juros) if object.juros.present?
  end

  def multa
    h.number_to_currency(object.multa) if object.multa.present?
  end

  def valor_atualizado
    h.number_to_currency(object.valor_atualizado) if object.valor_atualizado.present?
  end

  def guia_link
    return '' if object.guia.blank?
    h.link_to  h.admin_guia_path(object.guia), class: 'btn btn-light btn-sm' do
     "<i class='fas fa-barcode'></i> Visualizar guia".html_safe
    end
  end

  def public_guia_link
    return show_guia_link if object.guia.present?
    gerar_guia_link
  end

  def show_guia_link
    return '' if object&.guia.blank?
    h.link_to h.debito_parcela_guia_path(object&.debito&.hash_acesso, object, object.guia), class: 'btn btn-light btn-sm' do
     "<i class='fas fa-barcode'></i> Visualizar guia".html_safe
    end
  end

  def gerar_guia_link
    h.button_to 'Gerar guia', h.debito_parcela_guias_path(object.debito&.hash_acesso, object), class: 'btn btn-primary btn-sm',
                  form: { data: {turbo_confirm: "Confirmar a geração da guia referente à parcela n° #{object.numero}?"} }
  end

  def situacao
    I18n.t("activerecord.attributes.parcela.situacoes.#{object.situacao}")
  end

  def situacao_badge
    klass = case object.situacao
    when 'aguardando_confirmacao'
      'bg-info'
    when 'aguardando_pagamento'
      'bg-warning'
    when 'pago'
      'bg-success'
    when 'cancelado'
      'bg-danger'
    end
    "<span class='badge #{klass} rounded-pill'>#{situacao}</span>".html_safe
  end

end