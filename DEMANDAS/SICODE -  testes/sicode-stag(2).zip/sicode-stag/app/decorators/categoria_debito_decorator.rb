class CategoriaDebitoDecorator < ApplicationDecorator
  delegate_all

  def ativo
    object.ativo ? 'Sim' : 'Não'
  end

  def rules
    rules = []
    rules << "<span class='badge bg-primary'>Aplicar Correção (IPCA)</span> " if object.aplicar_correcao
    rules << "<span class='badge bg-primary'>Aplicar Juros (SELIC)</span> " if object.aplicar_juros
    rules << "<span class='badge bg-primary'>Aplicar Multa</span> " if object.aplicar_multa
    rules.join(' ').html_safe
  end
end