# This file should ensure the existence of records required to run the application in every environment (production,
# development, test). The code here should be idempotent so that it can be executed at any point in every environment.
# The data can then be loaded with the bin/rails db:seed command (or created alongside the database with db:setup).
#
# Example:
#
#   ["Action", "Comedy", "Drama", "Horror"].each do |genre_name|
#     MovieGenre.find_or_create_by!(name: genre_name)
#   end
# tipo_taxa: {emolumento: 1, taxa: 2, juros: 3, diversos: 4, fundos: 5, diferenca_debito: 6}

User.create!(username: 'dti', nome: 'Administrador', email: 'dti@tjgo.jus.br', role: 'admin', password: 'dti123456SD',
             password_confirmation: 'dti123456SD')

ItemArrecadacao.find_or_create_by(nome: 'Fundesp', codigo_arrecadacao: '5045', tipo_taxa: 1, ativo: true,
                                  data_inicio_vigencia: Date.new(2024, 1, 1), data_fim_vigencia: Date.new(2099, 12, 31))

ItemArrecadacao.find_or_create_by(nome: 'Multa', codigo_arrecadacao: '5244', tipo_taxa: 3, ativo: true,
                                  data_inicio_vigencia: Date.new(2024, 1, 1), data_fim_vigencia: Date.new(2099, 12, 31))

ItemArrecadacao.find_or_create_by(nome: 'Juros', codigo_arrecadacao: '5263', tipo_taxa: 3, ativo: true,
                                  data_inicio_vigencia: Date.new(2024, 1, 1), data_fim_vigencia: Date.new(2099, 12, 31))

# ItemArrecadacao.find_or_create_by(nome: 'Diferença de Débito', codigo_arrecadacao: '5203', tipo_taxa: 6, ativo: true, data_inicio_vigencia: Date.new(2024, 1, 1), data_fim_vigencia: Date.new(2099, 12, 31))

# itens especificos
debito_folha = CategoriaDebito.find_or_create_by(nome: 'Ressarcimento de Débitos da Folha', ativo: true,
                                                 aplicar_correcao: true, aplicar_juros: false, aplicar_multa: false)
# Ressarcimento de Débitos da Folha
# 5185 - Devolução de Vencimentos
ItemArrecadacao.find_or_create_by(nome: 'Devolução de Vencimentos', codigo_arrecadacao: '5185', tipo_taxa: 4,
                                  ativo: true, data_inicio_vigencia: Date.new(2024, 1, 1), data_fim_vigencia: Date.new(2099, 12, 31), categoria_debito_id: debito_folha.id)
# 1503 - Devolução de Auxílio Alimentação
ItemArrecadacao.find_or_create_by(nome: 'Devolução de Auxílio Alimentação', codigo_arrecadacao: '1503', tipo_taxa: 4,
                                  ativo: true, data_inicio_vigencia: Date.new(2024, 1, 1), data_fim_vigencia: Date.new(2099, 12, 31), categoria_debito_id: debito_folha.id)
# 1830 - Devolução de Auxílio Creche
ItemArrecadacao.find_or_create_by(nome: 'Devolução de Auxílio Creche', codigo_arrecadacao: '1830', tipo_taxa: 4,
                                  ativo: true, data_inicio_vigencia: Date.new(2024, 1, 1), data_fim_vigencia: Date.new(2099, 12, 31), categoria_debito_id: debito_folha.id)
# 1848 - Devolução de Auxílio Saúde
ItemArrecadacao.find_or_create_by(nome: 'Devolução de Auxílio Saúde', codigo_arrecadacao: '1848', tipo_taxa: 4,
                                  ativo: true, data_inicio_vigencia: Date.new(2024, 1, 1), data_fim_vigencia: Date.new(2099, 12, 31), categoria_debito_id: debito_folha.id)

# Custas Finais Protestadas
custas_finais = CategoriaDebito.find_or_create_by(nome: 'Custas Finais Protestadas', ativo: true)
# 5203 - Pagamento de débito
ItemArrecadacao.find_or_create_by(nome: 'Pagamento de débito', codigo_arrecadacao: '5203', tipo_taxa: 6, ativo: true,
                                  data_inicio_vigencia: Date.new(2024, 1, 1), data_fim_vigencia: Date.new(2099, 12, 31), categoria_debito_id: custas_finais.id)

# IPCA lê arquivo e atualiza a tabela
File.open("#{Rails.root}/db/ipca.csv").each do |line|
  puts line
  indicador = line.split(';')
  data_inicio = Date.new(indicador[0].to_i, indicador[1].to_i, 1)
  data_fim = data_inicio.end_of_month
  IndicadorFinanceiro.find_or_create_by(nome: "IPCA #{indicador[0]}/#{indicador[1]}",
                                        tipo: 'ipca',
                                        inicio: data_inicio,
                                        final: data_fim,
                                        valor: indicador[3].to_f,
                                        acumulado: indicador[2].to_f,
                                        ativo: true)
end
