class CreateCategoriaDebitos < ActiveRecord::Migration[7.1]
  def change
    create_table :categoria_debitos do |t|
      t.string :nome
      t.boolean :ativo

      t.timestamps
    end
  end
end
