class AddAcumuladoToIndicadoresFinanceiros < ActiveRecord::Migration[7.1]
  def change
    add_column :indicadores_financeiros, :acumulado, :float
  end
end
