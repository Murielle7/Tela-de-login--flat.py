class AddAtivaToParcela < ActiveRecord::Migration[7.1]
  def change
    add_column :parcelas, :ativa, :boolean, default: false
  end
end
