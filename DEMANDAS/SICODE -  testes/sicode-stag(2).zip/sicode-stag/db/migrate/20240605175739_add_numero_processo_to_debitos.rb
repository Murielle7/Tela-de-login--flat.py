class AddNumeroProcessoToDebitos < ActiveRecord::Migration[7.1]
  def change
    add_column :debitos, :numero_processo, :string
  end
end
