class CreateIndicadoresFinanceiros < ActiveRecord::Migration[7.1]
  def change
    create_table :indicadores_financeiros do |t|
      t.string :nome
      t.string :tipo
      t.decimal :valor, precision: 10, scale: 2
      t.date :inicio
      t.date :final
      t.boolean :ativo, default: true

      t.timestamps
    end
  end
end
