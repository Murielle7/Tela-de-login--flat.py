class AddCategoriaToItensArrecadacao < ActiveRecord::Migration[7.1]
  def change
    add_column :itens_arrecadacao, :categoria_debito_id, :integer
  end
end
