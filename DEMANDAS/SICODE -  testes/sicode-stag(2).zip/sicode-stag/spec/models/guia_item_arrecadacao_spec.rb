require 'rails_helper'

RSpec.describe GuiaItemArrecadacao, type: :model do
  describe 'associations' do
    it { should belong_to(:guia) }
    it { should belong_to(:item_arrecadacao) }
  end

  describe 'validations' do
    it { should validate_presence_of(:valor) }
  end

  describe 'public methods' do
    let!(:guia) { FactoryBot.create(:guia) }
    let!(:item_arrecadacao) { FactoryBot.create(:item_arrecadacao) }
    let!(:guia_item_arrecadacao) { FactoryBot.create(:guia_item_arrecadacao, guia: guia, item_arrecadacao: item_arrecadacao, valor: 1000.0) }


  end
end