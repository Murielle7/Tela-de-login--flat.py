# juro_spec.rb

require 'rails_helper'

RSpec.describe Juro, type: :model do
  context 'calcular' do
    before { allow(Indices::Selic).to receive(:indice_periodo).and_return(1.0)}
    it 'calcula juro' do
      juro = Juro.new(options: {valor_original: 1000.0, dias: 20, indice: 1.0, data_ref: Date.new(2017, 1, 21), data_final: Date.new(2017, 2, 11)})
      expect(juro.valor.to_f).to eq(10.0)
    end
  end

  context '.calcula_dias' do
    it 'data final informada' do
      j = Juro.new(options: {data_ref: Date.new(2017, 1, 1), data_final: Date.new(2017, 1, 31)})
      expect(j.dias).to eq(30)
    end

    it 'data final nao informada' do
      j = Juro.new(options: {data_ref: (Date.current - 10.days) })
      expect(j.dias).to eq(10)
    end
  end

  context '.indice_selic' do
    before do
      FactoryBot.create(:indicador_financeiro, tipo: 'selic', valor: 1.0, inicio: Date.new(2017, 1, 1), final: Date.new(2017, 1, 31))
      FactoryBot.create(:indicador_financeiro, tipo: 'selic', valor: 2.0, inicio: Date.new(2017, 2, 1), final: Date.new(2017, 2, 28))
      FactoryBot.create(:indicador_financeiro, tipo: 'selic', valor: 3.0, inicio: Date.new(2017, 3, 1), final: Date.new(2017, 3, 31))
    end

    # 1/2017 + 2/2017 + 1 do mês 3/2017
    it 'selic_periodo' do
      j = Juro.new(options: {data_ref: Date.new(2016, 12, 1), data_final: Date.new(2017, 3, 30)})
      expect(j.indice).to eq(4.0)
    end
  end
end

# Path: spec/models/juro_spec.rb