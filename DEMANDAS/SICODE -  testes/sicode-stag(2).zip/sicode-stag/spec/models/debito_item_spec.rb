require 'rails_helper'

RSpec.describe DebitoItem, type: :model do

  context 'validations' do
    it { should validate_presence_of(:valor_ref) }
    it { should validate_presence_of(:data_ref) }
  end

  context 'associations' do
    it { should belong_to(:debito) }
  end

  context 'public methods' do
    let!(:debito) { FactoryBot.create(:debito) }

    context 'atualizar_valores' do
      let!(:debito_item) { FactoryBot.create(:debito_item, debito: debito, valor_ref: 1000.0, data_ref: Date.new(2024, 1, 1)) }
      before do
        allow(Indices::Selic).to receive(:indice_periodo).and_return(1.0)
        Timecop.freeze(Date.new(2024, 4, 1))
        debito_item.atualizar_valores
      end

      it 'calcula correcao' do
        expect(debito_item.correcao).to eq(0)
      end

      it 'calcula juros' do
        expect(debito_item.juros).to eq(10.0)
      end

      it 'calcula multa' do
        expect(debito_item.multa).to eq(202)
      end

      it 'calcula valor atualizado' do
        expect(debito_item.valor_atualizado).to eq(1212.0)
      end

      it 'atualiza data de atualizacao' do
        expect(debito_item.data_atualizacao).to eq(Date.current)
      end
    end
  end
end